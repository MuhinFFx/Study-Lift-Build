package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.StudySession
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.SectionHeader
import com.example.ui.components.StudyReportExporter
import com.example.ui.components.formatRelativeTime
import com.example.ui.theme.LocalStudyLiftColors
import com.example.ui.theme.StudyLiftMonoFamily
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProgressScreen(
    accountState: UiState<UserAccount?>,
    sessionsState: UiState<List<StudySession>>,
    onLogSession: (subject: String, minutes: Long, mode: String) -> Unit,
    onExportFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showLogDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }

    val account = (accountState as? UiState.Success)?.data
    val sessions = (sessionsState as? UiState.Success)?.data.orEmpty()

    val csvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val saved = StudyReportExporter.writeCsvToUri(context, uri, account, sessions)
            onExportFeedback(
                if (saved) "Exported study progress CSV!" else "Could not write CSV file."
            )
        }
    }
    val dailyData = remember(sessions) { buildLastSevenDaysMinutes(sessions) }
    val todayMinutes = dailyData.lastOrNull()?.second ?: 0L
    val goalMinutes = (account?.dailyGoalMinutes ?: 90L).coerceAtLeast(10L)
    val goalProgress = (todayMinutes.toFloat() / goalMinutes.toFloat()).coerceIn(0f, 1f)
    val subjectTotals = remember(sessions) {
        sessions.groupBy { it.subject }
            .mapValues { (_, list) -> list.sumOf { it.durationMinutes } }
            .entries
            .sortedByDescending { it.value }
            .take(5)
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionHeader(
                    title = "Your Progress",
                    subtitle = "Track daily study lifts and export reports",
                    trailing = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { showExportDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("export_progress_button")
                            ) {
                                Icon(Icons.Filled.IosShare, contentDescription = "Export progress", modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Export")
                            }
                            Button(
                                onClick = { showLogDialog = true },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("log_study_session_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Log")
                            }
                        }
                    }
                )
            }

            // Daily Goal Progress
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Today's Lift Goal", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "$todayMinutes / $goalMinutes min",
                                style = MaterialTheme.typography.titleSmall.copy(fontFamily = StudyLiftMonoFamily),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { goalProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp),
                            strokeCap = StrokeCap.Round,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }

            // KPI Metrics Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        icon = Icons.Filled.Timer,
                        value = "${((account?.totalStudyMinutes ?: 0L) / 60.0).let { String.format(Locale.US, "%.1f", it) }}h",
                        label = "Total Time",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        icon = Icons.Filled.LocalFireDepartment,
                        value = "${account?.streakDays ?: 1}d",
                        label = "Streak",
                        tint = LocalStudyLiftColors.current.streak,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        icon = Icons.Filled.CheckCircle,
                        value = "${account?.sessionsCompleted ?: sessions.size.toLong()}",
                        label = "Sessions",
                        tint = LocalStudyLiftColors.current.online,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 7-Day Custom Canvas Bar Chart
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("Last 7 Days", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(14.dp))
                        val barColor = MaterialTheme.colorScheme.primary
                        val trackColor = MaterialTheme.colorScheme.surfaceVariant
                        val maxVal = (dailyData.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(goalMinutes)

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        ) {
                            val count = dailyData.size.coerceAtLeast(1)
                            val slotWidth = size.width / count
                            val barWidth = (slotWidth * 0.48f).coerceAtMost(36.dp.toPx())
                            dailyData.forEachIndexed { index, (_, mins) ->
                                val x = slotWidth * index + (slotWidth - barWidth) / 2f
                                drawRoundRect(
                                    color = trackColor,
                                    topLeft = Offset(x, 0f),
                                    size = Size(barWidth, size.height),
                                    cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                                )
                                val ratio = (mins.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                                val filledHeight = size.height * ratio
                                if (filledHeight > 0f) {
                                    drawRoundRect(
                                        color = barColor,
                                        topLeft = Offset(x, size.height - filledHeight),
                                        size = Size(barWidth, filledHeight),
                                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            dailyData.forEach { (dayLabel, _) ->
                                Text(
                                    text = dayLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            if (subjectTotals.isNotEmpty()) {
                item {
                    SectionHeader(title = "Top Subjects")
                    Spacer(Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        subjectTotals.forEach { (subj, mins) ->
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "$subj • ${mins}m",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "Recent Study Sessions")
            }

            when (sessionsState) {
                is UiState.Loading -> item { LoadingStateBox() }
                is UiState.Error -> item { ErrorStateBanner(sessionsState.message) }
                is UiState.Success -> {
                    if (sessions.isEmpty()) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Filled.AutoGraph,
                                title = "No sessions logged yet",
                                description = "Start the focus timer on Home, join a Study Together room, or tap Log above to record your progress.",
                                actionLabel = "Log First Session",
                                onAction = { showLogDialog = true }
                            )
                        }
                    } else {
                        items(sessions.take(15), key = { it.id }) { sess ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(sess.subject, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = buildString {
                                                append(if (sess.mode == "group") "Group Study" else "Solo Focus")
                                                if (sess.roomTitle.isNotBlank()) append(" • ${sess.roomTitle}")
                                                append(" • ${formatRelativeTime(sess.createdAt)}")
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "+${sess.durationMinutes}m",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontFamily = StudyLiftMonoFamily,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = LocalStudyLiftColors.current.online
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLogDialog) {
        LogStudySessionDialog(
            onDismiss = { showLogDialog = false },
            onConfirm = { subj, mins, mode ->
                showLogDialog = false
                onLogSession(subj, mins, mode)
            }
        )
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Export Study Report") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Save your Study Lift hours, streak, and ${sessions.size} logged sessions as a CSV file or share a quick summary.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = {
                            showExportDialog = false
                            csvLauncher.launch("study_lift_progress.csv")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_csv_confirm")
                    ) {
                        Icon(Icons.Filled.FileDownload, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Save CSV File")
                    }
                    OutlinedButton(
                        onClick = {
                            showExportDialog = false
                            StudyReportExporter.shareSummary(context, account, sessions)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_share_confirm")
                    ) {
                        Icon(Icons.Filled.IosShare, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share Summary")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun MetricCard(
    icon: ImageVector,
    value: String,
    label: String,
    tint: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = StudyLiftMonoFamily)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LogStudySessionDialog(
    onDismiss: () -> Unit,
    onConfirm: (subject: String, minutes: Long, mode: String) -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var duration by remember { mutableLongStateOf(25L) }
    var mode by remember { mutableStateOf("solo") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Study Lift") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    placeholder = { Text("e.g. Organic Chemistry") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("log_session_subject_input")
                )
                Text("Duration", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15L, 25L, 45L, 60L, 90L).forEach { mins ->
                        FilterChip(
                            selected = duration == mins,
                            onClick = { duration = mins },
                            label = { Text("${mins}m") }
                        )
                    }
                }
                Text("Study Mode", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = mode == "solo",
                        onClick = { mode = "solo" },
                        label = { Text("Solo") }
                    )
                    FilterChip(
                        selected = mode == "group",
                        onClick = { mode = "group" },
                        label = { Text("Group Study") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(subject.ifBlank { "Focused Study" }, duration, mode) },
                modifier = Modifier.testTag("log_session_confirm")
            ) {
                Text("Save Session")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

private fun buildLastSevenDaysMinutes(sessions: List<StudySession>): List<Pair<String, Long>> {
    val formatter = SimpleDateFormat("EEE", Locale.getDefault())
    val days = (6 downTo 0).map { offset ->
        Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -offset)
        }
    }
    return days.map { dayCal ->
        val year = dayCal.get(Calendar.YEAR)
        val dayOfYear = dayCal.get(Calendar.DAY_OF_YEAR)
        val total = sessions.sumOf { sess ->
            val date = sess.createdAt?.toDate()
            if (date != null) {
                val c = Calendar.getInstance().apply { time = date }
                if (c.get(Calendar.YEAR) == year && c.get(Calendar.DAY_OF_YEAR) == dayOfYear) {
                    sess.durationMinutes
                } else 0L
            } else 0L
        }
        formatter.format(dayCal.time) to total
    }
}

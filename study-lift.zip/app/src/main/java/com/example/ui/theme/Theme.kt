package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class StudyLiftExtendedColors(
    val online: Color,
    val onlineContainer: Color,
    val streak: Color,
    val streakContainer: Color,
    val badge: Color,
    val badgeContainer: Color,
    val cardElevated: Color
)

val LocalStudyLiftColors = staticCompositionLocalOf {
    StudyLiftExtendedColors(
        online = MintOnline,
        onlineContainer = MintContainer,
        streak = AmberStreak,
        streakContainer = AmberContainer,
        badge = CoralAlert,
        badgeContainer = CoralContainer,
        cardElevated = PureCardWhite
    )
}

private val LightColorScheme = lightColorScheme(
    primary = CobaltPrimary,
    onPrimary = Color.White,
    primaryContainer = CobaltPrimaryContainer,
    onPrimaryContainer = MidnightInk,
    secondary = MintOnline,
    onSecondary = Color.White,
    secondaryContainer = MintContainer,
    onSecondaryContainer = MidnightInk,
    tertiary = AmberStreak,
    onTertiary = MidnightInk,
    tertiaryContainer = AmberContainer,
    onTertiaryContainer = MidnightInk,
    error = CoralAlert,
    onError = Color.White,
    errorContainer = CoralContainer,
    onErrorContainer = MidnightInk,
    background = WarmParchment,
    onBackground = MidnightInk,
    surface = PureCardWhite,
    onSurface = MidnightInk,
    surfaceVariant = SoftCreamSurface,
    onSurfaceVariant = SlateMuted,
    outline = SubtleOutline
)

private val DarkColorScheme = darkColorScheme(
    primary = CobaltDarkPrimary,
    onPrimary = DarkBackground,
    primaryContainer = CobaltDarkContainer,
    onPrimaryContainer = Color.White,
    secondary = MintOnline,
    onSecondary = DarkBackground,
    secondaryContainer = Color(0xFF064E3B),
    onSecondaryContainer = MintContainer,
    tertiary = AmberStreak,
    onTertiary = DarkBackground,
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = AmberContainer,
    error = CoralAlert,
    onError = Color.White,
    errorContainer = Color(0xFF881337),
    onErrorContainer = CoralContainer,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkMuted,
    outline = DarkOutline
)

val StudyLiftShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun StudyLiftTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val extendedColors = if (darkTheme) {
        StudyLiftExtendedColors(
            online = MintOnline,
            onlineContainer = Color(0xFF064E3B),
            streak = AmberStreak,
            streakContainer = Color(0xFF78350F),
            badge = CoralAlert,
            badgeContainer = Color(0xFF881337),
            cardElevated = DarkSurface
        )
    } else {
        StudyLiftExtendedColors(
            online = MintOnline,
            onlineContainer = MintContainer,
            streak = AmberStreak,
            streakContainer = AmberContainer,
            badge = CoralAlert,
            badgeContainer = CoralContainer,
            cardElevated = PureCardWhite
        )
    }

    CompositionLocalProvider(LocalStudyLiftColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = StudyLiftTypography,
            shapes = StudyLiftShapes,
            content = content
        )
    }
}

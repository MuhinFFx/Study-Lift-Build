package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.PublicProfile
import com.example.data.model.StudyRoom
import com.example.data.model.UiState
import com.example.ui.components.ClassmateAvatar
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.SectionHeader
import com.example.ui.components.formatCountdown
import com.example.ui.theme.StudyLiftMonoFamily
import com.example.ui.viewmodel.FocusTimerState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateStudyRoomDialog(
    onDismiss: () -> Unit,
    onCreate: (title: String, subject: String, description: String, visibility: String, focusMinutes: Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var visibility by remember { mutableStateOf("open") }
    var focusMinutes by remember { mutableLongStateOf(25L) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Study Room") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Room Name") },
                    placeholder = { Text("e.g. Linear Algebra Sprint") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_room_title_input")
                )
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    placeholder = { Text("e.g. Mathematics") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_room_subject_input")
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Study Goal (optional)") },
                    placeholder = { Text("25/5 Pomodoro rounds") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Focus Duration", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15L, 25L, 45L, 60L).forEach { mins ->
                        FilterChip(
                            selected = focusMinutes == mins,
                            onClick = { focusMinutes = mins },
                            label = { Text("${mins}m") }
                        )
                    }
                }
                Text("Visibility", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = visibility == "open",
                        onClick = { visibility = "open" },
                        label = { Text("Open to Classmates") }
                    )
                    FilterChip(
                        selected = visibility == "invite",
                        onClick = { visibility = "invite" },
                        label = { Text("Invite Code Only") }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(title, subject, description, visibility, focusMinutes) },
                enabled = title.trim().isNotEmpty(),
                modifier = Modifier.testTag("create_room_submit_button")
            ) {
                Text("Launch Room")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun JoinRoomByCodeDialog(
    onDismiss: () -> Unit,
    onJoin: (String) -> Unit
) {
    var roomCode by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Join Study Room") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Enter a classmate's room code to join their study session and group chat.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = roomCode,
                    onValueChange = { roomCode = it.uppercase() },
                    label = { Text("Room Code") },
                    placeholder = { Text("e.g. RM-4821A") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("join_room_code_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onJoin(roomCode) },
                enabled = roomCode.trim().length >= 4,
                modifier = Modifier.testTag("join_room_code_submit")
            ) {
                Text("Join Room")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyRoomDetailScreen(
    currentUserId: String,
    roomState: UiState<StudyRoom?>,
    friends: List<PublicProfile>,
    focusTimer: FocusTimerState,
    onStartRoomTimer: (StudyRoom) -> Unit,
    onToggleTimer: () -> Unit,
    onCompleteTimer: () -> Unit,
    onOpenRoomChat: (String) -> Unit,
    onInviteFriend: (PublicProfile, StudyRoom) -> Unit,
    onAddFriendByUid: (String) -> Unit,
    onLeaveOrEndRoom: (StudyRoom) -> Unit,
    onCopyFeedback: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    var showInviteDialog by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Study Together", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("room_detail_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            when (roomState) {
                is UiState.Loading -> LoadingStateBox()
                is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorStateBanner(roomState.message) }
                is UiState.Success -> {
                    val room = roomState.data
                    if (room == null) {
                        Box(Modifier.padding(16.dp)) {
                            ErrorStateBanner("This study room is no longer available.")
                        }
                    } else {
                        val isHost = room.hostUid == currentUserId
                        val timerMatchesRoom = focusTimer.roomTitle == room.title

                        LazyColumn(
                            modifier = Modifier
                                .widthIn(max = 720.dp)
                                .fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Column {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(160.dp)
                                        ) {
                                            Image(
                                                painter = painterResource(id = R.drawable.img_study_room_banner),
                                                contentDescription = "Study room atmosphere",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(
                                                        Brush.verticalGradient(
                                                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                                                        )
                                                    )
                                            )
                                            Column(
                                                modifier = Modifier
                                                    .align(Alignment.BottomStart)
                                                    .padding(16.dp)
                                            ) {
                                                Text(room.subject, style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = 0.85f))
                                                Text(room.title, style = MaterialTheme.typography.headlineSmall, color = Color.White)
                                            }
                                        }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text("Room Code", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text(
                                                    text = room.roomCode,
                                                    style = MaterialTheme.typography.titleLarge.copy(fontFamily = StudyLiftMonoFamily)
                                                )
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(
                                                    onClick = {
                                                        clipboardManager.setText(AnnotatedString(room.roomCode))
                                                        onCopyFeedback("Copied Room Code ${room.roomCode}")
                                                    }
                                                ) {
                                                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Copy")
                                                }
                                                Button(
                                                    onClick = { showInviteDialog = true },
                                                    modifier = Modifier.testTag("room_invite_button")
                                                ) {
                                                    Icon(Icons.Filled.GroupAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Invite")
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Shared Focus Timer Card
                            item {
                                Card(
                                    shape = RoundedCornerShape(22.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(18.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "Room Focus Timer (${room.focusMinutes}m Sprint)",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = if (timerMatchesRoom) {
                                                formatCountdown(focusTimer.remainingSeconds)
                                            } else {
                                                formatCountdown(room.focusMinutes.toInt() * 60)
                                            },
                                            style = MaterialTheme.typography.displaySmall.copy(
                                                fontFamily = StudyLiftMonoFamily,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Spacer(Modifier.height(12.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            Button(
                                                onClick = {
                                                    if (timerMatchesRoom) onToggleTimer()
                                                    else onStartRoomTimer(room)
                                                },
                                                modifier = Modifier.testTag("room_timer_start_pause")
                                            ) {
                                                Icon(
                                                    imageVector = if (timerMatchesRoom && focusTimer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                                    contentDescription = null
                                                )
                                                Spacer(Modifier.width(6.dp))
                                                Text(if (timerMatchesRoom && focusTimer.running) "Pause" else "Start Focus")
                                            }
                                            if (timerMatchesRoom) {
                                                OutlinedButton(onClick = onCompleteTimer) {
                                                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                                    Spacer(Modifier.width(4.dp))
                                                    Text("Log Session")
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Open Group Study Chat CTA
                            if (room.conversationId.isNotBlank()) {
                                item {
                                    Button(
                                        onClick = { onOpenRoomChat(room.conversationId) },
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(52.dp)
                                            .testTag("room_open_chat_button")
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Open Group Study Chat")
                                    }
                                }
                            }

                            // Participants
                            item {
                                SectionHeader(
                                    title = "Studying Together (${room.participantUids.size})",
                                    subtitle = "Tap + to add a classmate as a friend"
                                )
                            }

                            items(room.participantUids, key = { it }) { uid ->
                                val name = room.participantNames[uid] ?: "Classmate"
                                val alreadyFriend = friends.any { it.userId == uid }
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        ClassmateAvatar(name = name, online = true, size = 42.dp)
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (uid == currentUserId) "$name (You)" else name,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = if (uid == room.hostUid) "Room Host" else "Participant",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (uid != currentUserId && !alreadyFriend) {
                                            IconButton(
                                                onClick = { onAddFriendByUid(uid) },
                                                modifier = Modifier.size(48.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.PersonAdd,
                                                    contentDescription = "Add $name as friend",
                                                    tint = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Leave / End Room
                            item {
                                OutlinedButton(
                                    onClick = { onLeaveOrEndRoom(room) },
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.error
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("room_leave_end_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (isHost) "End Study Room" else "Leave Study Room")
                                }
                            }
                        }

                        if (showInviteDialog) {
                            AlertDialog(
                                onDismissRequest = { showInviteDialog = false },
                                title = { Text("Invite Classmates") },
                                text = {
                                    if (friends.isEmpty()) {
                                        Text("Add friends first or share room code ${room.roomCode}.")
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.height(220.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            items(friends, key = { it.userId }) { friend ->
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            onInviteFriend(friend, room)
                                                            showInviteDialog = false
                                                        }
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        ClassmateAvatar(name = friend.displayName, online = friend.online, size = 36.dp)
                                                        Spacer(Modifier.width(10.dp))
                                                        Text(friend.displayName, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                                        Text("Invite", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    TextButton(onClick = { showInviteDialog = false }) { Text("Done") }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

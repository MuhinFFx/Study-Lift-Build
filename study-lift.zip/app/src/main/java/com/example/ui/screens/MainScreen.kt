package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.signOutUser
import com.example.data.model.UiState
import com.example.ui.components.StudyLiftLocalNotifier
import com.example.ui.viewmodel.StudyLiftViewModel

private enum class StudyLiftTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_tab_home"),
    CHAT("Chat", Icons.AutoMirrored.Filled.Chat, Icons.AutoMirrored.Outlined.Chat, "nav_tab_chat"),
    FRIENDS("Friends", Icons.Filled.Group, Icons.Outlined.Group, "nav_tab_friends"),
    PROGRESS("Progress", Icons.Filled.AutoGraph, Icons.Outlined.AutoGraph, "nav_tab_progress"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_tab_settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    currentUserId: String,
    viewModel: StudyLiftViewModel
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }

    val accountState by viewModel.userAccount.collectAsStateWithLifecycle()
    val friendRequestsState by viewModel.friendRequests.collectAsStateWithLifecycle()
    val friends by viewModel.friendProfiles.collectAsStateWithLifecycle()
    val conversationsState by viewModel.conversations.collectAsStateWithLifecycle()
    val myRoomsState by viewModel.myStudyRooms.collectAsStateWithLifecycle()
    val openRoomsState by viewModel.openStudyRooms.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notifications.collectAsStateWithLifecycle()
    val sessionsState by viewModel.studySessions.collectAsStateWithLifecycle()
    val activeConversationId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val activeMessagesState by viewModel.activeMessages.collectAsStateWithLifecycle()
    val activeRoomId by viewModel.activeRoomId.collectAsStateWithLifecycle()
    val activeRoomState by viewModel.activeRoom.collectAsStateWithLifecycle()
    val lookupState by viewModel.lookupState.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()
    val focusTimer by viewModel.focusTimer.collectAsStateWithLifecycle()

    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }
    var friendsInitialSubTab by remember { mutableIntStateOf(0) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showCreateRoomDialog by remember { mutableStateOf(false) }
    var showJoinRoomDialog by remember { mutableStateOf(false) }
    var lastNotifiedId by remember { mutableStateOf<String?>(null) }

    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
    val unreadChatCount = conversations.count { it.unreadByUids.contains(currentUserId) }
    val incomingRequestCount = (friendRequestsState as? UiState.Success)?.data
        ?.count { it.status == "pending" && it.toUid == currentUserId } ?: 0
    val notifications = (notificationsState as? UiState.Success)?.data.orEmpty()
    val unreadNotifCount = notifications.count { it.unread }
    val account = (accountState as? UiState.Success)?.data

    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    LaunchedEffect(notifications, account?.notificationsEnabled) {
        val newestUnread = notifications.firstOrNull { it.unread }
        if (newestUnread != null && newestUnread.id != lastNotifiedId) {
            if (lastNotifiedId != null && account?.notificationsEnabled == true) {
                StudyLiftLocalNotifier.postNotificationIfPermitted(
                    context = context,
                    id = newestUnread.id.hashCode(),
                    title = newestUnread.title,
                    body = newestUnread.body
                )
            }
            lastNotifiedId = newestUnread.id
        } else if (newestUnread == null && lastNotifiedId == null && notifications.isNotEmpty()) {
            lastNotifiedId = notifications.first().id
        }
    }

    // Sub-screen navigation: StudyRoomDetail or ChatDetail take full screen cleanly with BackHandler
    val activeConv = conversations.firstOrNull { it.id == activeConversationId }
    if (!activeConversationId.isNullOrBlank()) {
        ChatDetailScreen(
            currentUserId = currentUserId,
            conversation = activeConv,
            messagesState = activeMessagesState,
            onMarkRead = { viewModel.markConversationRead(it) },
            onSendMessage = { conv, text -> viewModel.sendMessage(conv, text) },
            onBack = { viewModel.setActiveConversation(null) }
        )
        return
    }

    if (!activeRoomId.isNullOrBlank()) {
        StudyRoomDetailScreen(
            currentUserId = currentUserId,
            roomState = activeRoomState,
            friends = friends,
            focusTimer = focusTimer,
            onStartRoomTimer = { room ->
                viewModel.startFocusTimer(
                    subject = room.subject,
                    minutes = room.focusMinutes.toInt(),
                    roomTitle = room.title,
                    mode = "group"
                )
            },
            onToggleTimer = { viewModel.toggleFocusTimer() },
            onCompleteTimer = { viewModel.completeAndLogFocusTimer() },
            onOpenRoomChat = { convId ->
                viewModel.setActiveRoom(null)
                selectedTabIndex = StudyLiftTab.CHAT.ordinal
                viewModel.setActiveConversation(convId)
            },
            onInviteFriend = { friend, room ->
                viewModel.inviteFriendToRoom(friend.userId, friend.displayName, room)
            },
            onAddFriendByUid = { uid -> viewModel.sendFriendRequestByUid(uid) },
            onLeaveOrEndRoom = { room ->
                viewModel.leaveOrEndStudyRoom(room) {
                    viewModel.setActiveRoom(null)
                }
            },
            onCopyFeedback = { viewModel.showFeedback(it) },
            onBack = { viewModel.setActiveRoom(null) }
        )
        return
    }

    val currentTab = StudyLiftTab.entries[selectedTabIndex]

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Study Lift",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (account != null) {
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = currentTab.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { showNotificationsSheet = true },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("notifications_bell_button")
                        ) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotifCount > 0) {
                                        Badge {
                                            Text(
                                                text = if (unreadNotifCount > 9) "9+" else unreadNotifCount.toString()
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = "Notifications"
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        StudyLiftTab.entries.forEachIndexed { index, tab ->
                            val selected = selectedTabIndex == index
                            val badgeCount = when (tab) {
                                StudyLiftTab.CHAT -> unreadChatCount
                                StudyLiftTab.FRIENDS -> incomingRequestCount
                                else -> 0
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (tab == StudyLiftTab.FRIENDS) friendsInitialSubTab = 0
                                    selectedTabIndex = index
                                },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (badgeCount > 0) {
                                                Badge { Text(badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    }
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        Column(
                            modifier = Modifier.fillMaxHeight(),
                            verticalArrangement = Arrangement.Center
                        ) {
                            StudyLiftTab.entries.forEachIndexed { index, tab ->
                                val selected = selectedTabIndex == index
                                val badgeCount = when (tab) {
                                    StudyLiftTab.CHAT -> unreadChatCount
                                    StudyLiftTab.FRIENDS -> incomingRequestCount
                                    else -> 0
                                }
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        if (tab == StudyLiftTab.FRIENDS) friendsInitialSubTab = 0
                                        selectedTabIndex = index
                                    },
                                    icon = {
                                        BadgedBox(
                                            badge = {
                                                if (badgeCount > 0) {
                                                    Badge { Text(badgeCount.toString()) }
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        }
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (currentTab) {
                        StudyLiftTab.HOME -> HomeScreen(
                            currentUserId = currentUserId,
                            accountState = accountState,
                            myRoomsState = myRoomsState,
                            openRoomsState = openRoomsState,
                            conversationsState = conversationsState,
                            sessionsState = sessionsState,
                            friends = friends,
                            focusTimer = focusTimer,
                            onCreateStudyRoomClick = { showCreateRoomDialog = true },
                            onJoinRoomByCodeClick = { showJoinRoomDialog = true },
                            onOpenStudyRoom = { room ->
                                viewModel.joinStudyRoom(room) { roomId ->
                                    viewModel.setActiveRoom(roomId)
                                }
                            },
                            onOpenChatTab = { selectedTabIndex = StudyLiftTab.CHAT.ordinal },
                            onOpenConversation = { convId ->
                                selectedTabIndex = StudyLiftTab.CHAT.ordinal
                                viewModel.setActiveConversation(convId)
                            },
                            onOpenAddFriends = {
                                friendsInitialSubTab = 2
                                selectedTabIndex = StudyLiftTab.FRIENDS.ordinal
                            },
                            onToggleFocusTimer = { viewModel.toggleFocusTimer() },
                            onCompleteFocusTimer = { viewModel.completeAndLogFocusTimer() },
                            onStartQuickFocus = { mins ->
                                viewModel.startFocusTimer("Focused Study", mins)
                            }
                        )

                        StudyLiftTab.CHAT -> ChatScreen(
                            currentUserId = currentUserId,
                            conversationsState = conversationsState,
                            friends = friends,
                            onOpenConversation = { convId -> viewModel.setActiveConversation(convId) },
                            onStartPrivateChat = { friendUid, friendName ->
                                viewModel.startOrOpenPrivateChat(friendUid, friendName) { convId ->
                                    viewModel.setActiveConversation(convId)
                                }
                            },
                            onCreateGroupChat = { title, selected ->
                                viewModel.createGroupChat(title, selected) { convId ->
                                    viewModel.setActiveConversation(convId)
                                }
                            },
                            onOpenFriendsTab = {
                                friendsInitialSubTab = 2
                                selectedTabIndex = StudyLiftTab.FRIENDS.ordinal
                            }
                        )

                        StudyLiftTab.FRIENDS -> FriendsScreen(
                            currentUserId = currentUserId,
                            accountState = accountState,
                            friends = friends,
                            requestsState = friendRequestsState,
                            lookupState = lookupState,
                            initialSubTab = friendsInitialSubTab,
                            onLookupClassmate = { viewModel.lookupClassmate(it) },
                            onResetLookup = { viewModel.resetLookup() },
                            onSendFriendRequest = { viewModel.sendFriendRequest(it) },
                            onRespondToRequest = { req, accept -> viewModel.respondToFriendRequest(req, accept) },
                            onMessageFriend = { friend ->
                                viewModel.startOrOpenPrivateChat(friend.userId, friend.displayName) { convId ->
                                    selectedTabIndex = StudyLiftTab.CHAT.ordinal
                                    viewModel.setActiveConversation(convId)
                                }
                            },
                            onCopyFeedback = { viewModel.showFeedback(it) }
                        )

                        StudyLiftTab.PROGRESS -> ProgressScreen(
                            accountState = accountState,
                            sessionsState = sessionsState,
                            onLogSession = { subject, minutes, mode ->
                                viewModel.logStudySession(subject, minutes, mode = mode)
                            },
                            onExportFeedback = { viewModel.showFeedback(it) }
                        )

                        StudyLiftTab.SETTINGS -> SettingsScreen(
                            accountState = accountState,
                            sessions = (sessionsState as? UiState.Success)?.data.orEmpty(),
                            onSaveSettings = { name, major, status, goal, notifs, online ->
                                viewModel.updateProfileAndSettings(name, major, status, goal, notifs, online)
                            },
                            onToggleOnline = { viewModel.toggleOnlineStatus(it) },
                            onCopyFeedback = { viewModel.showFeedback(it) },
                            onSignOutClick = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope,
                                    onBeforeSignOut = { viewModel.prepareSignOut() }
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCreateRoomDialog) {
        CreateStudyRoomDialog(
            onDismiss = { showCreateRoomDialog = false },
            onCreate = { title, subject, desc, visibility, mins ->
                showCreateRoomDialog = false
                viewModel.createStudyRoom(title, subject, desc, visibility, mins) { roomId ->
                    viewModel.setActiveRoom(roomId)
                }
            }
        )
    }

    if (showJoinRoomDialog) {
        JoinRoomByCodeDialog(
            onDismiss = { showJoinRoomDialog = false },
            onJoin = { code ->
                showJoinRoomDialog = false
                viewModel.joinRoomByCode(code) { roomId ->
                    viewModel.setActiveRoom(roomId)
                }
            }
        )
    }

    if (showNotificationsSheet) {
        NotificationsSheet(
            notificationsState = notificationsState,
            onDismiss = { showNotificationsSheet = false },
            onMarkAllRead = { viewModel.markAllNotificationsRead(it) },
            onNotificationClick = { notif ->
                if (notif.unread) viewModel.markNotificationRead(notif.id)
                showNotificationsSheet = false
                when (notif.notifType) {
                    "new_message" -> {
                        selectedTabIndex = StudyLiftTab.CHAT.ordinal
                        if (notif.targetId.isNotBlank()) {
                            viewModel.setActiveConversation(notif.targetId)
                        }
                    }
                    "friend_request" -> {
                        friendsInitialSubTab = 1
                        selectedTabIndex = StudyLiftTab.FRIENDS.ordinal
                    }
                    "study_invite" -> {
                        if (notif.targetId.isNotBlank()) {
                            viewModel.setActiveRoom(notif.targetId)
                        }
                    }
                    else -> {
                        selectedTabIndex = StudyLiftTab.PROGRESS.ordinal
                    }
                }
            }
        )
    }
}

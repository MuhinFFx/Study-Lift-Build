package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.FriendRequest
import com.example.data.model.PublicProfile
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.example.ui.components.ClassmateAvatar
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalStudyLiftColors
import com.example.ui.theme.StudyLiftMonoFamily
import com.example.ui.viewmodel.ClassmateLookupState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    currentUserId: String,
    accountState: UiState<UserAccount?>,
    friends: List<PublicProfile>,
    requestsState: UiState<List<FriendRequest>>,
    lookupState: ClassmateLookupState,
    initialSubTab: Int = 0,
    onLookupClassmate: (String) -> Unit,
    onResetLookup: () -> Unit,
    onSendFriendRequest: (PublicProfile) -> Unit,
    onRespondToRequest: (FriendRequest, Boolean) -> Unit,
    onMessageFriend: (PublicProfile) -> Unit,
    onCopyFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember(initialSubTab) { mutableIntStateOf(initialSubTab) }
    var selectedFriendProfile by remember { mutableStateOf<PublicProfile?>(null) }
    var codeQuery by remember { mutableStateOf("") }

    val clipboardManager = LocalClipboardManager.current
    val account = (accountState as? UiState.Success)?.data
    val allRequests = (requestsState as? UiState.Success)?.data.orEmpty()
    val incomingRequests = allRequests.filter { it.status == "pending" && it.toUid == currentUserId }
    val outgoingRequests = allRequests.filter { it.status == "pending" && it.fromUid == currentUserId }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
        ) {
            SecondaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Friends (${friends.size})") },
                    modifier = Modifier.testTag("friends_subtab_list")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        val badge = if (incomingRequests.isNotEmpty()) " (${incomingRequests.size})" else ""
                        Text("Requests$badge")
                    },
                    modifier = Modifier.testTag("friends_subtab_requests")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Add Friends") },
                    modifier = Modifier.testTag("friends_subtab_add")
                )
            }

            when (selectedTab) {
                0 -> {
                    if (requestsState is UiState.Loading && friends.isEmpty()) {
                        LoadingStateBox()
                    } else if (friends.isEmpty()) {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(22.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.img_empty_friends),
                                            contentDescription = "Connect with classmates",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(170.dp)
                                                .clip(RoundedCornerShape(16.dp))
                                        )
                                        Spacer(Modifier.height(14.dp))
                                        Text(
                                            text = "Build your study circle",
                                            style = MaterialTheme.typography.titleLarge
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = "See when classmates are online, check their study status, and jump into chats or Study Together rooms.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(Modifier.height(16.dp))
                                        Button(
                                            onClick = { selectedTab = 2 },
                                            modifier = Modifier.testTag("empty_friends_add_button")
                                        ) {
                                            Icon(Icons.Filled.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text("Add Classmates")
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val onlineCount = friends.count { it.online }
                            item {
                                SectionHeader(
                                    title = "Classmates",
                                    subtitle = "$onlineCount online • ${friends.size} connected"
                                )
                            }
                            items(friends, key = { it.userId }) { friend ->
                                FriendProfileRowCard(
                                    profile = friend,
                                    onClick = { selectedFriendProfile = friend },
                                    onMessageClick = { onMessageFriend(friend) }
                                )
                            }
                        }
                    }
                }

                1 -> {
                    when (requestsState) {
                        is UiState.Loading -> LoadingStateBox()
                        is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorStateBanner(requestsState.message) }
                        is UiState.Success -> {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                item {
                                    SectionHeader(
                                        title = "Incoming Requests",
                                        subtitle = if (incomingRequests.isEmpty()) "No pending requests" else "${incomingRequests.size} waiting"
                                    )
                                }
                                if (incomingRequests.isEmpty()) {
                                    item {
                                        Text(
                                            text = "Share your Study Code in Add Friends so classmates can connect with you.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                } else {
                                    items(incomingRequests, key = { it.id }) { req ->
                                        IncomingRequestCard(
                                            request = req,
                                            onAccept = { onRespondToRequest(req, true) },
                                            onDecline = { onRespondToRequest(req, false) }
                                        )
                                    }
                                }

                                if (outgoingRequests.isNotEmpty()) {
                                    item {
                                        Spacer(Modifier.height(6.dp))
                                        SectionHeader(
                                            title = "Sent Requests",
                                            subtitle = "${outgoingRequests.size} awaiting reply"
                                        )
                                    }
                                    items(outgoingRequests, key = { it.id }) { req ->
                                        Card(
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(14.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                ClassmateAvatar(name = req.toName, size = 42.dp)
                                                Spacer(Modifier.width(12.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(req.toName, style = MaterialTheme.typography.titleSmall)
                                                    Text(
                                                        text = req.toStudyCode.ifBlank { "Pending" },
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(50),
                                                    color = MaterialTheme.colorScheme.surfaceVariant
                                                ) {
                                                    Text(
                                                        text = "Pending",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Text(
                                        text = "Your Study Code",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = account?.studyCode?.ifBlank { "SL-..." } ?: "Loading...",
                                            style = MaterialTheme.typography.headlineMedium.copy(
                                                fontFamily = StudyLiftMonoFamily,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        FilledTonalButton(
                                            onClick = {
                                                val code = account?.studyCode.orEmpty()
                                                if (code.isNotBlank()) {
                                                    clipboardManager.setText(AnnotatedString(code))
                                                    onCopyFeedback("Copied Study Code $code")
                                                }
                                            },
                                            modifier = Modifier.testTag("copy_study_code_button")
                                        ) {
                                            Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Copy")
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = "Share this code with classmates so they can send you a friend request.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        item {
                            Card(
                                shape = RoundedCornerShape(22.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Text(
                                        text = "Find Classmate by Study Code",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(
                                        value = codeQuery,
                                        onValueChange = {
                                            codeQuery = it.uppercase()
                                            if (lookupState !is ClassmateLookupState.Idle) onResetLookup()
                                        },
                                        label = { Text("Classmate Study Code") },
                                        placeholder = { Text("e.g. SL-A1B2C3") },
                                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("add_friend_code_input")
                                    )
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = { onLookupClassmate(codeQuery) },
                                        enabled = codeQuery.trim().length >= 4 && lookupState !is ClassmateLookupState.Searching,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("lookup_classmate_button")
                                    ) {
                                        if (lookupState is ClassmateLookupState.Searching) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(18.dp),
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                strokeWidth = 2.dp
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Text("Searching...")
                                        } else {
                                            Text("Search Classmate")
                                        }
                                    }

                                    when (lookupState) {
                                        is ClassmateLookupState.Found -> {
                                            Spacer(Modifier.height(16.dp))
                                            val found = lookupState.profile
                                            val alreadyFriend = friends.any { it.userId == found.userId }
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(14.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    ClassmateAvatar(name = found.displayName, online = found.online)
                                                    Spacer(Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(found.displayName, style = MaterialTheme.typography.titleMedium)
                                                        Text(
                                                            text = found.major.ifBlank { found.studyCode },
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    if (alreadyFriend) {
                                                        OutlinedButton(onClick = { onMessageFriend(found) }) {
                                                            Text("Message")
                                                        }
                                                    } else {
                                                        Button(
                                                            onClick = { onSendFriendRequest(found) },
                                                            modifier = Modifier.testTag("send_friend_request_button")
                                                        ) {
                                                            Text("Add")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        is ClassmateLookupState.NotFound -> {
                                            Spacer(Modifier.height(12.dp))
                                            ErrorStateBanner(lookupState.message)
                                        }
                                        else -> Unit
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val sheetProfile = selectedFriendProfile
    if (sheetProfile != null) {
        ModalBottomSheet(onDismissRequest = { selectedFriendProfile = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ClassmateAvatar(name = sheetProfile.displayName, online = sheetProfile.online, size = 72.dp)
                Spacer(Modifier.height(12.dp))
                Text(sheetProfile.displayName, style = MaterialTheme.typography.headlineSmall)
                Text(
                    text = sheetProfile.major.ifBlank { "Study Lift Scholar" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (sheetProfile.online) {
                        LocalStudyLiftColors.current.onlineContainer
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = if (sheetProfile.online) {
                            "Online • ${sheetProfile.statusText.ifBlank { "Studying" }}"
                        } else {
                            "Offline"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (sheetProfile.online) {
                            LocalStudyLiftColors.current.online
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Timer, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("${sheetProfile.totalStudyMinutes}m", style = MaterialTheme.typography.titleMedium)
                                Text("Studied", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.LocalFireDepartment, contentDescription = null, tint = LocalStudyLiftColors.current.streak)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("${sheetProfile.streakDays} days", style = MaterialTheme.typography.titleMedium)
                                Text("Streak", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = {
                        selectedFriendProfile = null
                        onMessageFriend(sheetProfile)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Send Private Message")
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun FriendProfileRowCard(
    profile: PublicProfile,
    onClick: () -> Unit,
    onMessageClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("friend_card_${profile.userId}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ClassmateAvatar(name = profile.displayName, online = profile.online, size = 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (profile.online) {
                        profile.statusText.ifBlank { "Online now" }
                    } else {
                        profile.major.ifBlank { "Offline" }
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (profile.online) LocalStudyLiftColors.current.online else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onMessageClick,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Chat,
                    contentDescription = "Message ${profile.displayName}",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun IncomingRequestCard(
    request: FriendRequest,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ClassmateAvatar(name = request.fromName, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(request.fromName, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = request.fromMajor.ifBlank { request.fromStudyCode },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = onDecline, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.Close, contentDescription = "Decline request", tint = MaterialTheme.colorScheme.error)
            }
            IconButton(onClick = onAccept, modifier = Modifier.size(48.dp)) {
                Icon(Icons.Filled.Check, contentDescription = "Accept request", tint = LocalStudyLiftColors.current.online)
            }
        }
    }
}

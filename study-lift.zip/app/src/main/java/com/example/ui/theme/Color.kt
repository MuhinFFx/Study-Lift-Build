package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette — Warm Academic Lift
val CobaltPrimary = Color(0xFF2E5CFA)
val CobaltPrimaryContainer = Color(0xFFDFE6FF)
val MidnightInk = Color(0xFF132238)
val WarmParchment = Color(0xFFFBF9F5)
val SoftCreamSurface = Color(0xFFF3EFE6)
val PureCardWhite = Color(0xFFFFFFFF)
val SlateMuted = Color(0xFF5A687C)
val SubtleOutline = Color(0xFFE2DDD2)

// Accents & Semantic
val MintOnline = Color(0xFF10B981)
val MintContainer = Color(0xFFD1FAE5)
val AmberStreak = Color(0xFFF59E0B)
val AmberContainer = Color(0xFFFEF3C7)
val CoralAlert = Color(0xFFF43F5E)
val CoralContainer = Color(0xFFFFE4E6)

// Dark Palette — Late-Night Library
val DarkBackground = Color(0xFF0B1220)
val DarkSurface = Color(0xFF131D31)
val DarkSurfaceVariant = Color(0xFF1D2B44)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkMuted = Color(0xFF94A3B8)
val CobaltDarkPrimary = Color(0xFF7B9BFF)
val CobaltDarkContainer = Color(0xFF1B337A)
val DarkOutline = Color(0xFF2C3B59)

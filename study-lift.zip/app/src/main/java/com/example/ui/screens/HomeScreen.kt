package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Conversation
import com.example.data.model.PublicProfile
import com.example.data.model.StudyRoom
import com.example.data.model.StudySession
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.example.ui.components.ClassmateAvatar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.SectionHeader
import com.example.ui.components.formatCountdown
import com.example.ui.components.formatRelativeTime
import com.example.ui.theme.LocalStudyLiftColors
import com.example.ui.theme.StudyLiftMonoFamily
import com.example.ui.viewmodel.FocusTimerState
import java.util.Calendar

@Composable
fun HomeScreen(
    currentUserId: String,
    accountState: UiState<UserAccount?>,
    myRoomsState: UiState<List<StudyRoom>>,
    openRoomsState: UiState<List<StudyRoom>>,
    conversationsState: UiState<List<Conversation>>,
    sessionsState: UiState<List<StudySession>>,
    friends: List<PublicProfile>,
    focusTimer: FocusTimerState,
    onCreateStudyRoomClick: () -> Unit,
    onJoinRoomByCodeClick: () -> Unit,
    onOpenStudyRoom: (StudyRoom) -> Unit,
    onOpenChatTab: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onOpenAddFriends: () -> Unit,
    onToggleFocusTimer: () -> Unit,
    onCompleteFocusTimer: () -> Unit,
    onStartQuickFocus: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val account = (accountState as? UiState.Success)?.data
    val sessions = (sessionsState as? UiState.Success)?.data.orEmpty()
    val myRooms = (myRoomsState as? UiState.Success)?.data.orEmpty()
    val openRooms = (openRoomsState as? UiState.Success)?.data.orEmpty()
    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()

    val todayMinutes = rememberTodayMinutes(sessions)
    val goalMinutes = (account?.dailyGoalMinutes ?: 90L).coerceAtLeast(10L)
    val goalProgress = (todayMinutes.toFloat() / goalMinutes.toFloat()).coerceIn(0f, 1f)

    val combinedRooms = (myRooms + openRooms).distinctBy { it.id }
    val unreadConversations = conversations.filter { it.unreadByUids.contains(currentUserId) }
    val onlineFriends = friends.filter { it.online }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Hero Welcome & Daily Goal Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(144.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_hero_study_lift),
                                contentDescription = "Study Lift collaborative workspace banner",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Black.copy(alpha = 0.15f),
                                                Color.Black.copy(alpha = 0.72f)
                                            )
                                        )
                                    )
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Hey ${account?.displayName?.substringBefore(" ") ?: "Scholar"}!",
                                        style = MaterialTheme.typography.headlineSmall,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = account?.statusText?.ifBlank { "Ready for today's study lift" }
                                            ?: "Loading your study space...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.88f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = LocalStudyLiftColors.current.streakContainer
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.LocalFireDepartment,
                                            contentDescription = "Streak days",
                                            tint = LocalStudyLiftColors.current.streak,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = "${account?.streakDays ?: 1}d streak",
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(62.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = { goalProgress },
                                    modifier = Modifier.fillMaxSize(),
                                    strokeWidth = 6.dp,
                                    strokeCap = StrokeCap.Round,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                                Text(
                                    text = "${(goalProgress * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontFamily = StudyLiftMonoFamily,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Today's Focus Lift",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "$todayMinutes of $goalMinutes min goal",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            FilledTonalButton(
                                onClick = { onStartQuickFocus(25) },
                                modifier = Modifier.testTag("home_quick_focus_button")
                            ) {
                                Icon(Icons.Filled.Timer, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("25m")
                            }
                        }
                    }
                }
            }

            // 2. Quick Actions Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionTile(
                        icon = Icons.Filled.Groups,
                        label = "Study Room",
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.primary,
                        onClick = onCreateStudyRoomClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_create_room")
                    )
                    QuickActionTile(
                        icon = Icons.Filled.Key,
                        label = "Join Code",
                        containerColor = LocalStudyLiftColors.current.onlineContainer,
                        contentColor = LocalStudyLiftColors.current.online,
                        onClick = onJoinRoomByCodeClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_join_code")
                    )
                    QuickActionTile(
                        icon = Icons.Filled.PersonAdd,
                        label = "Add Friend",
                        containerColor = LocalStudyLiftColors.current.streakContainer,
                        contentColor = LocalStudyLiftColors.current.streak,
                        onClick = onOpenAddFriends,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_add_friend")
                    )
                }
            }

            // 3. Active Focus Timer Banner (when active or customized)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (focusTimer.running) "Focus Session Active" else "Focus Timer Ready",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = focusTimer.subject,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = formatCountdown(focusTimer.remainingSeconds),
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontFamily = StudyLiftMonoFamily
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalIconButton(
                                onClick = onToggleFocusTimer,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("home_timer_toggle")
                            ) {
                                Icon(
                                    imageVector = if (focusTimer.running) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = if (focusTimer.running) "Pause timer" else "Start timer"
                                )
                            }
                            FilledTonalIconButton(
                                onClick = onCompleteFocusTimer,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("home_timer_complete")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Complete and log study session"
                                )
                            }
                        }
                    }
                }
            }

            // 4. Unread Message Alerts Strip
            if (unreadConversations.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "New Messages (${unreadConversations.size})",
                        trailing = {
                            OutlinedButton(onClick = onOpenChatTab) {
                                Text("View All")
                            }
                        }
                    )
                }
                items(unreadConversations.take(2), key = { "unread_${it.id}" }) { conv ->
                    val displayTitle = resolveConversationTitle(conv, currentUserId)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenConversation(conv.id) },
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(displayTitle, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(conv.lastMessageText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = formatRelativeTime(conv.lastMessageAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            // 5. Study Together Rooms
            item {
                SectionHeader(
                    title = "Study Together",
                    subtitle = "Join an open room or start your own",
                    trailing = {
                        Button(
                            onClick = onCreateStudyRoomClick,
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("home_create_room_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Create")
                        }
                    }
                )
            }

            when {
                myRoomsState is UiState.Loading && openRoomsState is UiState.Loading -> {
                    item { LoadingStateBox() }
                }
                myRoomsState is UiState.Error -> {
                    item { ErrorStateBanner(myRoomsState.message) }
                }
                combinedRooms.isEmpty() -> {
                    item {
                        EmptyStateCard(
                            icon = Icons.Filled.School,
                            title = "No live study rooms yet",
                            description = "Create a Study Together room with a focus timer and group chat, or join a classmate's room with a code.",
                            actionLabel = "Create Study Room",
                            onAction = onCreateStudyRoomClick
                        )
                    }
                }
                else -> {
                    items(combinedRooms, key = { it.id }) { room ->
                        StudyRoomCard(
                            room = room,
                            isJoined = room.participantUids.contains(currentUserId),
                            onClick = { onOpenStudyRoom(room) }
                        )
                    }
                }
            }

            // 6. Online Classmates Strip
            if (onlineFriends.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Classmates Online",
                        subtitle = "${onlineFriends.size} active right now"
                    )
                }
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(onlineFriends, key = { it.userId }) { friend ->
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                                modifier = Modifier.width(136.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    ClassmateAvatar(name = friend.displayName, online = friend.online)
                                    Spacer(Modifier.height(8.dp))
                                    Text(
                                        text = friend.displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = friend.statusText.ifBlank { "Online" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun QuickActionTile(
    icon: ImageVector,
    label: String,
    containerColor: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(containerColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = contentColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StudyRoomCard(
    room: StudyRoom,
    isJoined: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("study_room_card_${room.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = room.subject,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = room.roomCode,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = StudyLiftMonoFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isJoined) LocalStudyLiftColors.current.onlineContainer else MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = if (isJoined) "Joined" else "${room.focusMinutes}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isJoined) LocalStudyLiftColors.current.online else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = room.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (room.description.isNotBlank()) {
                Spacer(Modifier.height(3.dp))
                Text(
                    text = room.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Host: ${room.hostName} • ${room.participantUids.size} studying",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (isJoined) "Enter Room →" else "Join Room →",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

fun resolveConversationTitle(conversation: Conversation, currentUserId: String): String {
    if (conversation.chatType == "group") return conversation.title
    val otherName = conversation.participantNames.entries
        .firstOrNull { it.key != currentUserId }
        ?.value
    return otherName?.ifBlank { conversation.title } ?: conversation.title
}

private fun rememberTodayMinutes(sessions: List<StudySession>): Long {
    val todayCal = Calendar.getInstance()
    val todayYear = todayCal.get(Calendar.YEAR)
    val todayDay = todayCal.get(Calendar.DAY_OF_YEAR)
    return sessions.sumOf { sess ->
        val date = sess.createdAt?.toDate()
        if (date != null) {
            val cal = Calendar.getInstance().apply { time = date }
            if (cal.get(Calendar.YEAR) == todayYear && cal.get(Calendar.DAY_OF_YEAR) == todayDay) {
                sess.durationMinutes
            } else 0L
        } else 0L
    }
}

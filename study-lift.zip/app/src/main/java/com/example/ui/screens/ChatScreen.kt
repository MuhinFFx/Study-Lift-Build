package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Conversation
import com.example.data.model.PublicProfile
import com.example.data.model.UiState
import com.example.ui.components.ClassmateAvatar
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.formatRelativeTime

@Composable
fun ChatScreen(
    currentUserId: String,
    conversationsState: UiState<List<Conversation>>,
    friends: List<PublicProfile>,
    onOpenConversation: (String) -> Unit,
    onStartPrivateChat: (String, String) -> Unit,
    onCreateGroupChat: (String, List<PublicProfile>) -> Unit,
    onOpenFriendsTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf("all") }
    var showNewChatDialog by remember { mutableStateOf(false) }

    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
    val filteredConversations = remember(conversations, selectedFilter) {
        when (selectedFilter) {
            "private" -> conversations.filter { it.chatType == "private" }
            "group" -> conversations.filter { it.chatType == "group" }
            else -> conversations
        }
    }

    val onlineMap = remember(friends) { friends.associate { it.userId to it.online } }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewChatDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("new_chat_fab")
            ) {
                Icon(Icons.Filled.AddComment, contentDescription = "Start new chat")
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == "all",
                        onClick = { selectedFilter = "all" },
                        label = { Text("All (${conversations.size})") },
                        modifier = Modifier.testTag("chat_filter_all")
                    )
                    FilterChip(
                        selected = selectedFilter == "private",
                        onClick = { selectedFilter = "private" },
                        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Private") },
                        modifier = Modifier.testTag("chat_filter_private")
                    )
                    FilterChip(
                        selected = selectedFilter == "group",
                        onClick = { selectedFilter = "group" },
                        leadingIcon = { Icon(Icons.Filled.Groups, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Group Study") },
                        modifier = Modifier.testTag("chat_filter_group")
                    )
                }

                when (conversationsState) {
                    is UiState.Loading -> LoadingStateBox()
                    is UiState.Error -> ErrorStateBanner(conversationsState.message)
                    is UiState.Success -> {
                        if (filteredConversations.isEmpty()) {
                            Spacer(Modifier.height(16.dp))
                            EmptyStateCard(
                                icon = Icons.AutoMirrored.Filled.Chat,
                                title = "No conversations here yet",
                                description = if (friends.isEmpty()) {
                                    "Add classmates in Friends or join a Study Together room to start chatting."
                                } else {
                                    "Tap the compose button below to start a private chat or a group study conversation."
                                },
                                actionLabel = if (friends.isEmpty()) "Find Classmates" else "New Chat",
                                onAction = {
                                    if (friends.isEmpty()) onOpenFriendsTab() else showNewChatDialog = true
                                }
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(top = 4.dp, bottom = 88.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredConversations, key = { it.id }) { conv ->
                                    val isUnread = conv.unreadByUids.contains(currentUserId)
                                    val title = resolveConversationTitle(conv, currentUserId)
                                    val peerUid = conv.participantUids.firstOrNull { it != currentUserId }
                                    val peerOnline = if (conv.chatType == "private" && peerUid != null) {
                                        onlineMap[peerUid]
                                    } else null

                                    ConversationCard(
                                        conversation = conv,
                                        title = title,
                                        isUnread = isUnread,
                                        peerOnline = peerOnline,
                                        onClick = { onOpenConversation(conv.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewChatDialog) {
        NewChatDialog(
            friends = friends,
            onDismiss = { showNewChatDialog = false },
            onSelectFriendForPrivate = { friend ->
                showNewChatDialog = false
                onStartPrivateChat(friend.userId, friend.displayName)
            },
            onCreateGroup = { title, selected ->
                showNewChatDialog = false
                onCreateGroupChat(title, selected)
            }
        )
    }
}

@Composable
private fun ConversationCard(
    conversation: Conversation,
    title: String,
    isUnread: Boolean,
    peerOnline: Boolean?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("conversation_card_${conversation.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUnread) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isUnread) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (conversation.chatType == "group") {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Groups,
                            contentDescription = "Group study chat",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            } else {
                ClassmateAvatar(
                    name = title,
                    online = peerOnline,
                    size = 48.dp
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (conversation.chatType == "group") {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "${conversation.participantUids.size}",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(
                    text = conversation.lastMessageText.ifBlank { "No messages yet" },
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isUnread) FontWeight.Medium else FontWeight.Normal
                    ),
                    color = if (isUnread) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.width(10.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatRelativeTime(conversation.lastMessageAt),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isUnread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isUnread) {
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
            }
        }
    }
}

@Composable
private fun NewChatDialog(
    friends: List<PublicProfile>,
    onDismiss: () -> Unit,
    onSelectFriendForPrivate: (PublicProfile) -> Unit,
    onCreateGroup: (String, List<PublicProfile>) -> Unit
) {
    var tabIndex by remember { mutableIntStateOf(0) }
    var groupTitle by remember { mutableStateOf("") }
    val selectedForGroup = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Start a Conversation") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                TabRow(selectedTabIndex = tabIndex) {
                    Tab(
                        selected = tabIndex == 0,
                        onClick = { tabIndex = 0 },
                        text = { Text("Private") }
                    )
                    Tab(
                        selected = tabIndex == 1,
                        onClick = { tabIndex = 1 },
                        text = { Text("Group Study") }
                    )
                }
                Spacer(Modifier.height(14.dp))

                if (tabIndex == 0) {
                    if (friends.isEmpty()) {
                        Text(
                            text = "Add classmates in the Friends tab first to start a private chat.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.height(220.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(friends, key = { it.userId }) { friend ->
                                Surface(
                                    onClick = { onSelectFriendForPrivate(friend) },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        ClassmateAvatar(name = friend.displayName, online = friend.online, size = 38.dp)
                                        Spacer(Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(friend.displayName, style = MaterialTheme.typography.titleSmall)
                                            Text(friend.major.ifBlank { "Classmate" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = groupTitle,
                        onValueChange = { groupTitle = it },
                        label = { Text("Group Study Topic") },
                        placeholder = { Text("e.g. Calculus Midterm Prep") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("group_chat_title_input")
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Select classmates (optional):",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    if (friends.isEmpty()) {
                        Text(
                            text = "You can create the group now and invite classmates later.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.height(160.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(friends, key = { it.userId }) { friend ->
                                val checked = selectedForGroup.contains(friend.userId)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (checked) selectedForGroup.remove(friend.userId)
                                            else selectedForGroup.add(friend.userId)
                                        }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = checked,
                                        onCheckedChange = { isChecked ->
                                            if (isChecked) selectedForGroup.add(friend.userId)
                                            else selectedForGroup.remove(friend.userId)
                                        }
                                    )
                                    Text(friend.displayName, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (tabIndex == 1) {
                Button(
                    onClick = {
                        val picked = friends.filter { selectedForGroup.contains(it.userId) }
                        onCreateGroup(groupTitle.trim(), picked)
                    },
                    enabled = groupTitle.trim().isNotEmpty(),
                    modifier = Modifier.testTag("create_group_chat_confirm")
                ) {
                    Text("Create Group")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

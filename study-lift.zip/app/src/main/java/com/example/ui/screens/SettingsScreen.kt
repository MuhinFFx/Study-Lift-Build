package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.model.StudySession
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.example.ui.components.ClassmateAvatar
import com.example.ui.components.ErrorStateBanner
import com.example.ui.components.LoadingStateBox
import com.example.ui.components.SectionHeader
import com.example.ui.components.StudyReportExporter
import com.example.ui.theme.StudyLiftMonoFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    accountState: UiState<UserAccount?>,
    sessions: List<StudySession>,
    onSaveSettings: (
        displayName: String,
        major: String,
        statusText: String,
        dailyGoalMinutes: Long,
        notificationsEnabled: Boolean,
        online: Boolean
    ) -> Unit,
    onToggleOnline: (Boolean) -> Unit,
    onCopyFeedback: (String) -> Unit,
    onSignOutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val account = (accountState as? UiState.Success)?.data

    val csvExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) {
            val saved = StudyReportExporter.writeCsvToUri(context, uri, account, sessions)
            onCopyFeedback(if (saved) "Exported study_lift_progress.csv" else "Could not write CSV file.")
        }
    }

    var displayName by remember { mutableStateOf("") }
    var major by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf("") }
    var dailyGoal by remember { mutableLongStateOf(90L) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var online by remember { mutableStateOf(true) }
    var initializedForUid by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(account) {
        if (account != null && initializedForUid != account.userId) {
            displayName = account.displayName
            major = account.major
            statusText = account.statusText
            dailyGoal = account.dailyGoalMinutes
            notificationsEnabled = account.notificationsEnabled
            online = account.online
            initializedForUid = account.userId
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            onCopyFeedback("System notifications enabled!")
        } else {
            onCopyFeedback("Notification permission denied; in-app alerts remain active.")
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (accountState) {
            is UiState.Loading -> LoadingStateBox()
            is UiState.Error -> Box(Modifier.padding(16.dp)) { ErrorStateBanner(accountState.message) }
            is UiState.Success -> {
                LazyColumn(
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        SectionHeader(
                            title = "Settings & Profile",
                            subtitle = "Customize your study presence, goals, and alerts"
                        )
                    }

                    // Profile Header Card
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ClassmateAvatar(
                                    name = displayName.ifBlank { account?.displayName ?: "Scholar" },
                                    online = online,
                                    size = 56.dp
                                )
                                Spacer(Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = displayName.ifBlank { account?.displayName ?: "Scholar" },
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text(
                                        text = account?.email.orEmpty(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Code: ${account?.studyCode.orEmpty()}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = StudyLiftMonoFamily),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        val code = account?.studyCode.orEmpty()
                                        if (code.isNotBlank()) {
                                            clipboardManager.setText(AnnotatedString(code))
                                            onCopyFeedback("Copied Study Code $code")
                                        }
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy Study Code")
                                }
                            }
                        }
                    }

                    // Online Status & Notification Toggles
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Appear Online to Friends", style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = "Let classmates see your live online status",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = online,
                                        onCheckedChange = {
                                            online = it
                                            onToggleOnline(it)
                                        },
                                        modifier = Modifier.testTag("settings_online_switch")
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Message & Invite Alerts", style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = "Notify me for new chats and study room invites",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = notificationsEnabled,
                                        onCheckedChange = { enabled ->
                                            notificationsEnabled = enabled
                                            if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                val granted = ContextCompat.checkSelfPermission(
                                                    context,
                                                    Manifest.permission.POST_NOTIFICATIONS
                                                ) == PackageManager.PERMISSION_GRANTED
                                                if (!granted) {
                                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                                }
                                            }
                                        },
                                        modifier = Modifier.testTag("settings_notifications_switch")
                                    )
                                }
                            }
                        }
                    }

                    // Edit Study Profile & Daily Goal
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("Study Identity & Goal", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(
                                    value = displayName,
                                    onValueChange = { displayName = it },
                                    label = { Text("Display Name") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("settings_name_input")
                                )
                                OutlinedTextField(
                                    value = major,
                                    onValueChange = { major = it },
                                    label = { Text("Major / Focus Area") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("settings_major_input")
                                )
                                OutlinedTextField(
                                    value = statusText,
                                    onValueChange = { statusText = it },
                                    label = { Text("Current Study Status") },
                                    placeholder = { Text("e.g. Studying Calculus II") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("settings_status_input")
                                )

                                Text("Daily Study Goal", style = MaterialTheme.typography.labelMedium)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(30L, 60L, 90L, 120L, 180L).forEach { mins ->
                                        FilterChip(
                                            selected = dailyGoal == mins,
                                            onClick = { dailyGoal = mins },
                                            label = { Text("${mins}m") }
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        onSaveSettings(
                                            displayName,
                                            major,
                                            statusText,
                                            dailyGoal,
                                            notificationsEnabled,
                                            online
                                        )
                                    },
                                    enabled = displayName.trim().isNotEmpty(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("settings_save_button")
                                ) {
                                    Icon(Icons.Filled.Save, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Save Changes")
                                }
                            }
                        }
                    }

                    // Export Study Data
                    item {
                        OutlinedButton(
                            onClick = { csvExportLauncher.launch("study_lift_progress.csv") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("settings_export_button")
                        ) {
                            Icon(Icons.Filled.FileDownload, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Export Study Progress (CSV)")
                        }
                    }

                    // Sign Out
                    item {
                        OutlinedButton(
                            onClick = onSignOutClick,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("settings_sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Sign Out")
                        }
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

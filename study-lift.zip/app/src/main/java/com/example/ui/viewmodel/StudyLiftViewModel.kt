package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.StudyLiftRepository
import com.example.data.model.AppNotification
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.FriendRequest
import com.example.data.model.PublicProfile
import com.example.data.model.StudyRoom
import com.example.data.model.StudySession
import com.example.data.model.UiState
import com.example.data.model.UserAccount
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ClassmateLookupState {
    data object Idle : ClassmateLookupState
    data object Searching : ClassmateLookupState
    data class Found(val profile: PublicProfile) : ClassmateLookupState
    data class NotFound(val message: String) : ClassmateLookupState
}

data class FocusTimerState(
    val subject: String = "Deep Focus",
    val roomTitle: String = "",
    val mode: String = "solo",
    val totalMinutes: Int = 25,
    val remainingSeconds: Int = 25 * 60,
    val running: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class StudyLiftViewModel(
    private val repository: StudyLiftRepository,
    private val currentUserId: String,
    firebaseUser: FirebaseUser?
) : ViewModel() {

    private companion object {
        const val TAG = "StudyLiftVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }

    private fun <T> Flow<T>.toUiStateFlow(label: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Failed to load $label"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val userAccount: StateFlow<UiState<UserAccount?>> =
        repository.observeUserAccount(currentUserId).toUiStateFlow("account")

    val friendRequests: StateFlow<UiState<List<FriendRequest>>> =
        repository.observeFriendRequests(currentUserId).toUiStateFlow("friend requests")

    val friendProfiles: StateFlow<List<PublicProfile>> =
        repository.observeFriendRequests(currentUserId)
            .map { requests ->
                requests.filter { it.status == "accepted" }
                    .map { req -> if (req.fromUid == currentUserId) req.toUid else req.fromUid }
                    .distinct()
            }
            .flatMapLatest { friendUids ->
                repository.observeFriendProfiles(currentUserId, friendUids)
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Error observing friend profiles", firestoreError ?: error)
                emit(emptyList())
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = emptyList()
            )

    val conversations: StateFlow<UiState<List<Conversation>>> =
        repository.observeConversations(currentUserId).toUiStateFlow("conversations")

    val myStudyRooms: StateFlow<UiState<List<StudyRoom>>> =
        repository.observeMyStudyRooms(currentUserId).toUiStateFlow("my study rooms")

    val openStudyRooms: StateFlow<UiState<List<StudyRoom>>> =
        repository.observeOpenStudyRooms(currentUserId).toUiStateFlow("open study rooms")

    val notifications: StateFlow<UiState<List<AppNotification>>> =
        repository.observeNotifications(currentUserId).toUiStateFlow("notifications")

    val studySessions: StateFlow<UiState<List<StudySession>>> =
        repository.observeStudySessions(currentUserId).toUiStateFlow("study sessions")

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    val activeMessages: StateFlow<UiState<List<ChatMessage>>> =
        _activeConversationId
            .flatMapLatest { convId ->
                if (convId.isNullOrBlank()) flowOf(emptyList())
                else repository.observeMessages(convId, currentUserId)
            }
            .toUiStateFlow("messages")

    private val _activeRoomId = MutableStateFlow<String?>(null)
    val activeRoomId: StateFlow<String?> = _activeRoomId.asStateFlow()

    val activeRoom: StateFlow<UiState<StudyRoom?>> =
        _activeRoomId
            .flatMapLatest { roomId ->
                if (roomId.isNullOrBlank()) flowOf(null)
                else repository.observeStudyRoom(roomId, currentUserId)
            }
            .toUiStateFlow("study room")

    private val _lookupState = MutableStateFlow<ClassmateLookupState>(ClassmateLookupState.Idle)
    val lookupState: StateFlow<ClassmateLookupState> = _lookupState.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _focusTimer = MutableStateFlow(FocusTimerState())
    val focusTimer: StateFlow<FocusTimerState> = _focusTimer.asStateFlow()
    private var timerJob: Job? = null

    init {
        if (firebaseUser != null) {
            viewModelScope.launch {
                val result = repository.ensureUserInitialized(firebaseUser)
                result.onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to sync your Study Lift profile."
                }
            }
        }
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun showFeedback(message: String) {
        _feedbackMessage.value = message
    }

    fun setActiveConversation(conversationId: String?) {
        _activeConversationId.value = conversationId
    }

    fun setActiveRoom(roomId: String?) {
        _activeRoomId.value = roomId
    }

    fun resetLookup() {
        _lookupState.value = ClassmateLookupState.Idle
    }

    private fun currentAccountOrNull(): UserAccount? =
        (userAccount.value as? UiState.Success)?.data

    // --- Friends & Add Friends ---

    fun lookupClassmate(studyCode: String) {
        viewModelScope.launch {
            _lookupState.value = ClassmateLookupState.Searching
            repository.lookupClassmateByStudyCode(studyCode)
                .onSuccess { _lookupState.value = ClassmateLookupState.Found(it) }
                .onFailure {
                    _lookupState.value = ClassmateLookupState.NotFound(
                        it.localizedMessage ?: "No classmate found."
                    )
                }
        }
    }

    fun sendFriendRequest(target: PublicProfile) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.sendFriendRequest(account, target)
                .onSuccess {
                    _feedbackMessage.value = "Friend request sent to ${target.displayName}!"
                    _lookupState.value = ClassmateLookupState.Idle
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not send friend request."
                }
        }
    }

    fun sendFriendRequestByUid(targetUid: String) {
        val account = currentAccountOrNull() ?: return
        if (targetUid == currentUserId) return
        viewModelScope.launch {
            repository.fetchPublicProfile(targetUid)
                .onSuccess { profile ->
                    repository.sendFriendRequest(account, profile)
                        .onSuccess {
                            _feedbackMessage.value = "Friend request sent to ${profile.displayName}!"
                        }
                        .onFailure {
                            _feedbackMessage.value = it.localizedMessage ?: "Could not send request."
                        }
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Profile unavailable."
                }
        }
    }

    fun respondToFriendRequest(request: FriendRequest, accept: Boolean) {
        viewModelScope.launch {
            repository.respondToFriendRequest(request, accept)
                .onSuccess {
                    _feedbackMessage.value = if (accept) {
                        "Connected with ${request.fromName}!"
                    } else {
                        "Request declined."
                    }
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to update request."
                }
        }
    }

    // --- Chat Actions ---

    fun startOrOpenPrivateChat(friendUid: String, friendName: String, onOpen: (String) -> Unit) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.openOrCreatePrivateChat(account, friendUid, friendName)
                .onSuccess { convId -> onOpen(convId) }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not open chat."
                }
        }
    }

    fun createGroupChat(title: String, selectedFriends: List<PublicProfile>, onCreated: (String) -> Unit) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.createGroupChat(account, title, selectedFriends)
                .onSuccess { convId ->
                    _feedbackMessage.value = "Group chat \"$title\" created!"
                    onCreated(convId)
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not create group chat."
                }
        }
    }

    fun sendMessage(conversation: Conversation, text: String) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.sendMessage(conversation, account, text)
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Message failed to send."
                }
        }
    }

    fun markConversationRead(conversation: Conversation) {
        viewModelScope.launch {
            repository.markConversationRead(conversation, currentUserId)
        }
    }

    // --- Study Together Rooms ---

    fun createStudyRoom(
        title: String,
        subject: String,
        description: String,
        visibility: String,
        focusMinutes: Long,
        onCreated: (String) -> Unit
    ) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.createStudyRoom(account, title, subject, description, visibility, focusMinutes)
                .onSuccess { roomId ->
                    _feedbackMessage.value = "Study room \"$title\" is live!"
                    onCreated(roomId)
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to create study room."
                }
        }
    }

    fun joinRoomByCode(roomCode: String, onJoined: (String) -> Unit) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.joinStudyRoomByCode(account, roomCode)
                .onSuccess { roomId ->
                    _feedbackMessage.value = "Joined study room!"
                    onJoined(roomId)
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not join room."
                }
        }
    }

    fun joinStudyRoom(room: StudyRoom, onJoined: (String) -> Unit) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.joinStudyRoom(account, room)
                .onSuccess { onJoined(room.id) }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not join room."
                }
        }
    }

    fun leaveOrEndStudyRoom(room: StudyRoom, onLeft: () -> Unit) {
        viewModelScope.launch {
            repository.leaveStudyRoom(currentUserId, room)
                .onSuccess {
                    _feedbackMessage.value = if (room.hostUid == currentUserId) {
                        "Study room ended."
                    } else {
                        "Left study room."
                    }
                    onLeft()
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Could not leave room."
                }
        }
    }

    fun inviteFriendToRoom(friendUid: String, friendName: String, room: StudyRoom) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.inviteFriendToRoom(account, friendUid, room)
                .onSuccess {
                    _feedbackMessage.value = "Invited $friendName to ${room.title}!"
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Invite failed."
                }
        }
    }

    // --- Notifications ---

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            repository.markNotificationRead(currentUserId, notificationId)
        }
    }

    fun markAllNotificationsRead(notificationsList: List<AppNotification>) {
        val unreadIds = notificationsList.filter { it.unread }.map { it.id }
        if (unreadIds.isEmpty()) return
        viewModelScope.launch {
            repository.markAllNotificationsRead(currentUserId, unreadIds)
        }
    }

    // --- Progress & Focus Timer ---

    fun startFocusTimer(subject: String, minutes: Int, roomTitle: String = "", mode: String = "solo") {
        timerJob?.cancel()
        val clamped = minutes.coerceIn(5, 180)
        _focusTimer.value = FocusTimerState(
            subject = subject.ifBlank { "Deep Focus" },
            roomTitle = roomTitle,
            mode = mode,
            totalMinutes = clamped,
            remainingSeconds = clamped * 60,
            running = true
        )
        runTimerLoop()
    }

    fun toggleFocusTimer() {
        val current = _focusTimer.value
        if (current.running) {
            timerJob?.cancel()
            _focusTimer.value = current.copy(running = false)
        } else {
            if (current.remainingSeconds <= 0) {
                _focusTimer.value = current.copy(
                    remainingSeconds = current.totalMinutes * 60,
                    running = true
                )
            } else {
                _focusTimer.value = current.copy(running = true)
            }
            runTimerLoop()
        }
    }

    fun resetFocusTimer() {
        timerJob?.cancel()
        val current = _focusTimer.value
        _focusTimer.value = current.copy(
            remainingSeconds = current.totalMinutes * 60,
            running = false
        )
    }

    fun completeAndLogFocusTimer() {
        timerJob?.cancel()
        val current = _focusTimer.value
        val elapsedMinutes = ((current.totalMinutes * 60 - current.remainingSeconds) / 60)
            .coerceAtLeast(1)
        _focusTimer.value = current.copy(
            remainingSeconds = current.totalMinutes * 60,
            running = false
        )
        logStudySession(
            subject = current.subject,
            durationMinutes = elapsedMinutes.toLong(),
            roomTitle = current.roomTitle,
            mode = current.mode
        )
    }

    private fun runTimerLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val current = _focusTimer.value
                if (!current.running) break
                if (current.remainingSeconds <= 1) {
                    _focusTimer.value = current.copy(
                        remainingSeconds = current.totalMinutes * 60,
                        running = false
                    )
                    logStudySession(
                        subject = current.subject,
                        durationMinutes = current.totalMinutes.toLong(),
                        roomTitle = current.roomTitle,
                        mode = current.mode
                    )
                    break
                } else {
                    _focusTimer.value = current.copy(remainingSeconds = current.remainingSeconds - 1)
                }
            }
        }
    }

    fun logStudySession(
        subject: String,
        durationMinutes: Long,
        roomTitle: String = "",
        mode: String = "solo"
    ) {
        viewModelScope.launch {
            repository.logStudySession(currentUserId, subject, durationMinutes, roomTitle, mode)
                .onSuccess {
                    _feedbackMessage.value = "Logged ${durationMinutes}m of $subject! Keep lifting!"
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to log study session."
                }
        }
    }

    // --- Settings & Presence ---

    fun updateProfileAndSettings(
        displayName: String,
        major: String,
        statusText: String,
        dailyGoalMinutes: Long,
        notificationsEnabled: Boolean,
        online: Boolean
    ) {
        val account = currentAccountOrNull() ?: return
        viewModelScope.launch {
            repository.updateProfileAndSettings(
                account = account,
                displayName = displayName,
                major = major,
                statusText = statusText,
                dailyGoalMinutes = dailyGoalMinutes,
                notificationsEnabled = notificationsEnabled,
                online = online
            ).onSuccess {
                _feedbackMessage.value = "Settings saved!"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "Could not save settings."
            }
        }
    }

    fun toggleOnlineStatus(online: Boolean) {
        viewModelScope.launch {
            repository.setOnlineStatus(online)
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "Failed to update online status."
                }
        }
    }

    suspend fun prepareSignOut() {
        timerJob?.cancel()
        repository.setOnlineStatus(false)
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

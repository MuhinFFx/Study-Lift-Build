package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.model.StudySession
import com.example.data.model.UserAccount
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object StudyReportExporter {
    fun buildCsvContent(account: UserAccount?, sessions: List<StudySession>): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val sb = StringBuilder()
        sb.appendLine("Student,StudyCode,TotalMinutes,StreakDays,DailyGoalMinutes")
        sb.appendLine(
            listOf(
                escapeCsv(account?.displayName ?: "Scholar"),
                escapeCsv(account?.studyCode ?: ""),
                (account?.totalStudyMinutes ?: 0L).toString(),
                (account?.streakDays ?: 1L).toString(),
                (account?.dailyGoalMinutes ?: 90L).toString()
            ).joinToString(",")
        )
        sb.appendLine()
        sb.appendLine("Date,Subject,DurationMinutes,Mode,RoomTitle")
        sessions.forEach { sess ->
            val dateStr = sess.createdAt?.toDate()?.let { dateFormat.format(it) } ?: dateFormat.format(Date())
            sb.appendLine(
                listOf(
                    escapeCsv(dateStr),
                    escapeCsv(sess.subject),
                    sess.durationMinutes.toString(),
                    escapeCsv(sess.mode),
                    escapeCsv(sess.roomTitle)
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildShareSummary(account: UserAccount?, sessions: List<StudySession>): String {
        val totalMinutes = account?.totalStudyMinutes ?: sessions.sumOf { it.durationMinutes }
        val hours = String.format(Locale.US, "%.1f", totalMinutes / 60.0)
        val streak = account?.streakDays ?: 1L
        val topSubjects = sessions.groupBy { it.subject }
            .mapValues { (_, list) -> list.sumOf { it.durationMinutes } }
            .entries
            .sortedByDescending { it.value }
            .take(3)
            .joinToString(", ") { "${it.key} (${it.value}m)" }
            .ifBlank { "Getting started" }

        return buildString {
            appendLine("Study Lift Progress Report — ${account?.displayName ?: "Scholar"}")
            appendLine("Study Code: ${account?.studyCode.orEmpty()}")
            appendLine("Total Studied: $hours hrs ($totalMinutes min)")
            appendLine("Current Streak: $streak days")
            appendLine("Sessions Completed: ${sessions.size}")
            appendLine("Top Subjects: $topSubjects")
        }
    }

    fun writeCsvToUri(context: Context, uri: Uri, account: UserAccount?, sessions: List<StudySession>): Boolean {
        return try {
            val csv = buildCsvContent(account, sessions)
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(csv.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: return false
            true
        } catch (_: Exception) {
            false
        }
    }

    fun shareSummary(context: Context, account: UserAccount?, sessions: List<StudySession>) {
        val text = buildShareSummary(account, sessions)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Study Lift Progress Report")
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(sendIntent, "Export Study Lift Report")
        context.startActivity(chooser)
    }

    private fun escapeCsv(value: String): String {
        val cleaned = value.replace("\"", "\"\"")
        return "\"$cleaned\""
    }
}

package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.AppNotification
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.FriendRequest
import com.example.data.model.PublicProfile
import com.example.data.model.RoomCodeEntry
import com.example.data.model.StudyCodeEntry
import com.example.data.model.StudyRoom
import com.example.data.model.StudySession
import com.example.data.model.UserAccount
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudyLiftRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun generateStudyCode(uid: String): String {
        val clean = uid.replace(Regex("[^a-zA-Z0-9]"), "").uppercase()
        val suffix = (clean + "STUDYLIFT").take(6)
        return "SL-$suffix"
    }

    private fun generateRoomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val code = (1..5).map { chars.random() }.joinToString("")
        return "RM-$code"
    }

    private fun deterministicPairId(uidA: String, uidB: String): String {
        return if (uidA < uidB) "${uidA}_${uidB}" else "${uidB}_${uidA}"
    }

    private fun deterministicDmId(uidA: String, uidB: String): String {
        return if (uidA < uidB) "dm_${uidA}_${uidB}" else "dm_${uidB}_${uidA}"
    }

    private fun <T> Flow<T>.logFirestoreErrors(
        uid: String,
        operationType: OperationType,
        path: String
    ): Flow<T> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
        throw error
    }

    // --- Account Initialization ---

    suspend fun ensureUserInitialized(firebaseUser: FirebaseUser): Result<Unit> {
        val uid = firebaseUser.uid
        val userDocPath = "users/$uid"
        return try {
            val currentUid = requireUserId()
            check(currentUid == uid) { "Signed-in user mismatch." }
            val userRef = db.collection("users").document(uid)
            val publicRef = db.collection("public_profiles").document(uid)
            val snapshot = userRef.get().await()

            val displayName = (firebaseUser.displayName?.takeIf { it.isNotBlank() } ?: "Student").take(50)
            val email = (firebaseUser.email ?: "").take(120)

            if (!snapshot.exists()) {
                val studyCode = generateStudyCode(uid)
                val codeRef = db.collection("study_codes").document(studyCode)
                val batch = db.batch()
                batch.set(
                    userRef,
                    mapOf(
                        "userId" to uid,
                        "email" to email,
                        "displayName" to displayName,
                        "studyCode" to studyCode,
                        "major" to "General Studies",
                        "statusText" to "Ready to study",
                        "online" to true,
                        "dailyGoalMinutes" to 90L,
                        "notificationsEnabled" to true,
                        "totalStudyMinutes" to 0L,
                        "streakDays" to 1L,
                        "sessionsCompleted" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    publicRef,
                    mapOf(
                        "userId" to uid,
                        "displayName" to displayName,
                        "studyCode" to studyCode,
                        "major" to "General Studies",
                        "statusText" to "Ready to study",
                        "online" to true,
                        "totalStudyMinutes" to 0L,
                        "streakDays" to 1L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(
                    codeRef,
                    mapOf(
                        "userId" to uid,
                        "displayName" to displayName,
                        "major" to "General Studies",
                        "studyCode" to studyCode,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.commit().await()
            } else {
                val existingCode = snapshot.getString("studyCode") ?: generateStudyCode(uid)
                val batch = db.batch()
                batch.update(
                    userRef,
                    mapOf(
                        "online" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                val publicSnap = publicRef.get().await()
                if (publicSnap.exists()) {
                    batch.update(
                        publicRef,
                        mapOf(
                            "online" to true,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    batch.set(
                        publicRef,
                        mapOf(
                            "userId" to uid,
                            "displayName" to (snapshot.getString("displayName") ?: displayName),
                            "studyCode" to existingCode,
                            "major" to (snapshot.getString("major") ?: "General Studies"),
                            "statusText" to (snapshot.getString("statusText") ?: "Ready to study"),
                            "online" to true,
                            "totalStudyMinutes" to (snapshot.getLong("totalStudyMinutes") ?: 0L),
                            "streakDays" to (snapshot.getLong("streakDays") ?: 1L),
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userDocPath)
            Result.failure(e)
        }
    }

    // --- Real-Time Streams ---

    fun observeUserAccount(uid: String): Flow<UserAccount?> {
        if (uid.isBlank()) return flowOf(null)
        val path = "users/$uid"
        return db.collection("users").document(uid)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserAccount::class.java, ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .logFirestoreErrors(uid, OperationType.GET, path)
    }

    fun observeFriendRequests(uid: String): Flow<List<FriendRequest>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "friend_requests"
        return db.collection("friend_requests")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(FriendRequest::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeFriendProfiles(currentUid: String, friendUids: List<String>): Flow<List<PublicProfile>> {
        if (currentUid.isBlank() || friendUids.isEmpty()) return flowOf(emptyList())
        val limited = friendUids.distinct().take(40)
        val profileFlows = limited.map { friendUid ->
            db.collection("public_profiles").document(friendUid)
                .snapshots()
                .map { snap ->
                    if (snap.exists()) {
                        snap.toObject(PublicProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                    } else null
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(null)
                }
        }
        return combine(profileFlows) { profiles ->
            profiles.filterNotNull()
                .sortedWith(compareByDescending<PublicProfile> { it.online }.thenBy { it.displayName })
        }
    }

    fun observeConversations(uid: String): Flow<List<Conversation>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "conversations"
        return db.collection("conversations")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Conversation::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.lastMessageAt ?: it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeMessages(conversationId: String, uid: String): Flow<List<ChatMessage>> {
        if (uid.isBlank() || conversationId.isBlank()) return flowOf(emptyList())
        val path = "conversations/$conversationId/messages"
        return db.collection("conversations")
            .document(conversationId)
            .collection("messages")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.createdAt ?: Timestamp.now() }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeMyStudyRooms(uid: String): Flow<List<StudyRoom>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "study_rooms"
        return db.collection("study_rooms")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(StudyRoom::class.java, ServerTimestampBehavior.ESTIMATE)
                    .filter { it.status != "ended" }
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeOpenStudyRooms(uid: String): Flow<List<StudyRoom>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "study_rooms"
        return db.collection("study_rooms")
            .whereEqualTo("visibility", "open")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(StudyRoom::class.java, ServerTimestampBehavior.ESTIMATE)
                    .filter { it.status != "ended" }
                    .sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeStudyRoom(roomId: String, uid: String): Flow<StudyRoom?> {
        if (uid.isBlank() || roomId.isBlank()) return flowOf(null)
        val path = "study_rooms/$roomId"
        return db.collection("study_rooms").document(roomId)
            .snapshots()
            .map { snap ->
                if (snap.exists()) {
                    snap.toObject(StudyRoom::class.java, ServerTimestampBehavior.ESTIMATE)
                } else null
            }
            .logFirestoreErrors(uid, OperationType.GET, path)
    }

    fun observeNotifications(uid: String): Flow<List<AppNotification>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "users/$uid/notifications"
        return db.collection("users").document(uid)
            .collection("notifications")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(AppNotification::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    fun observeStudySessions(uid: String): Flow<List<StudySession>> {
        if (uid.isBlank()) return flowOf(emptyList())
        val path = "users/$uid/study_sessions"
        return db.collection("users").document(uid)
            .collection("study_sessions")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(StudySession::class.java, ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .logFirestoreErrors(uid, OperationType.LIST, path)
    }

    // --- Profile & Settings Mutations ---

    suspend fun updateProfileAndSettings(
        account: UserAccount,
        displayName: String,
        major: String,
        statusText: String,
        dailyGoalMinutes: Long,
        notificationsEnabled: Boolean,
        online: Boolean
    ): Result<Unit> {
        val uid = auth.currentUser?.uid
        val path = "users/${uid ?: "unauthenticated"}"
        return try {
            val activeUid = requireUserId()
            val cleanName = displayName.trim().take(50)
            require(cleanName.isNotEmpty()) { "Display name cannot be empty." }
            val cleanMajor = major.trim().take(60)
            val cleanStatus = statusText.trim().take(80)
            val clampedGoal = dailyGoalMinutes.coerceIn(10L, 600L)

            val batch = db.batch()
            batch.update(
                db.collection("users").document(activeUid),
                mapOf(
                    "displayName" to cleanName,
                    "major" to cleanMajor,
                    "statusText" to cleanStatus,
                    "dailyGoalMinutes" to clampedGoal,
                    "notificationsEnabled" to notificationsEnabled,
                    "online" to online,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("public_profiles").document(activeUid),
                mapOf(
                    "displayName" to cleanName,
                    "major" to cleanMajor,
                    "statusText" to cleanStatus,
                    "online" to online,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (account.studyCode.isNotBlank()) {
                batch.update(
                    db.collection("study_codes").document(account.studyCode),
                    mapOf(
                        "displayName" to cleanName,
                        "major" to cleanMajor,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun setOnlineStatus(online: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid
        val path = "users/${uid ?: "unauthenticated"}"
        return try {
            val activeUid = requireUserId()
            val batch = db.batch()
            batch.update(
                db.collection("users").document(activeUid),
                mapOf("online" to online, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.update(
                db.collection("public_profiles").document(activeUid),
                mapOf("online" to online, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- Add Friends & Friend Requests ---

    suspend fun lookupClassmateByStudyCode(rawCode: String): Result<PublicProfile> {
        val cleanCode = rawCode.trim().uppercase()
        val path = "study_codes/$cleanCode"
        return try {
            val activeUid = requireUserId()
            require(cleanCode.matches(Regex("^[A-Z0-9\\-]{4,20}$"))) {
                "Enter a valid Study Code (e.g. SL-ABC123)."
            }
            val codeSnap = db.collection("study_codes").document(cleanCode).get().await()
            if (!codeSnap.exists()) {
                return Result.failure(IllegalArgumentException("No classmate found with code $cleanCode."))
            }
            val targetUid = codeSnap.getString("userId")
                ?: return Result.failure(IllegalStateException("Study code record is incomplete."))
            if (targetUid == activeUid) {
                return Result.failure(IllegalArgumentException("That is your own Study Code!"))
            }
            val profileSnap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = profileSnap.toObject(PublicProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: PublicProfile(
                    id = targetUid,
                    userId = targetUid,
                    displayName = codeSnap.getString("displayName") ?: "Classmate",
                    studyCode = cleanCode,
                    major = codeSnap.getString("major") ?: ""
                )
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun fetchPublicProfile(targetUid: String): Result<PublicProfile> {
        val path = "public_profiles/$targetUid"
        return try {
            requireUserId()
            require(targetUid.isNotBlank()) { "User ID required." }
            val snap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = snap.toObject(PublicProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Classmate profile not found."))
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun sendFriendRequest(
        currentUser: UserAccount,
        target: PublicProfile
    ): Result<Unit> {
        val reqId = deterministicPairId(currentUser.userId, target.userId)
        val path = "friend_requests/$reqId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == currentUser.userId) { "Signed-in user mismatch." }
            require(target.userId != activeUid) { "Cannot add yourself as a friend." }

            val reqRef = db.collection("friend_requests").document(reqId)
            val existing = reqRef.get().await()
            if (existing.exists()) {
                val status = existing.getString("status")
                if (status == "accepted") {
                    return Result.failure(IllegalStateException("You are already friends with ${target.displayName}."))
                } else if (status == "pending") {
                    return Result.failure(IllegalStateException("A friend request is already pending."))
                } else {
                    reqRef.delete().await()
                }
            }

            val notifRef = db.collection("users").document(target.userId)
                .collection("notifications").document()
            val batch = db.batch()
            batch.set(
                reqRef,
                mapOf(
                    "fromUid" to activeUid,
                    "fromName" to currentUser.displayName.take(50).ifBlank { "Classmate" },
                    "fromMajor" to currentUser.major.take(60),
                    "fromStudyCode" to currentUser.studyCode.take(20),
                    "toUid" to target.userId,
                    "toName" to target.displayName.take(50).ifBlank { "Classmate" },
                    "toMajor" to target.major.take(60),
                    "toStudyCode" to target.studyCode.take(20),
                    "participantUids" to listOf(activeUid, target.userId),
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                notifRef,
                mapOf(
                    "recipientUid" to target.userId,
                    "senderUid" to activeUid,
                    "senderName" to currentUser.displayName.take(50).ifBlank { "Classmate" },
                    "notifType" to "friend_request",
                    "title" to "New friend request",
                    "body" to "${currentUser.displayName} wants to connect on Study Lift.",
                    "targetId" to reqId,
                    "unread" to true,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun respondToFriendRequest(request: FriendRequest, accept: Boolean): Result<Unit> {
        val path = "friend_requests/${request.id}"
        return try {
            val activeUid = requireUserId()
            require(request.toUid == activeUid) { "Only the recipient can respond to this request." }
            val newStatus = if (accept) "accepted" else "declined"
            db.collection("friend_requests").document(request.id)
                .update(
                    mapOf(
                        "status" to newStatus,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- Chats (Private & Group Study) ---

    suspend fun openOrCreatePrivateChat(
        currentUser: UserAccount,
        friendUid: String,
        friendName: String
    ): Result<String> {
        val dmId = deterministicDmId(currentUser.userId, friendUid)
        val path = "conversations/$dmId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == currentUser.userId)
            val convRef = db.collection("conversations").document(dmId)
            val snap = convRef.get().await()
            if (!snap.exists()) {
                val myName = currentUser.displayName.take(50).ifBlank { "Student" }
                val peerName = friendName.take(50).ifBlank { "Classmate" }
                convRef.set(
                    mapOf(
                        "title" to peerName,
                        "chatType" to "private",
                        "createdBy" to activeUid,
                        "participantUids" to listOf(activeUid, friendUid),
                        "participantNames" to mapOf(activeUid to myName, friendUid to peerName),
                        "lastMessageText" to "Started a private study chat",
                        "lastMessageSenderId" to activeUid,
                        "lastMessageSenderName" to myName,
                        "lastMessageAt" to FieldValue.serverTimestamp(),
                        "unreadByUids" to emptyList<String>(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(dmId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun createGroupChat(
        currentUser: UserAccount,
        title: String,
        friends: List<PublicProfile>
    ): Result<String> {
        val convRef = db.collection("conversations").document()
        val path = convRef.path
        return try {
            val activeUid = requireUserId()
            val cleanTitle = title.trim().take(80)
            require(cleanTitle.isNotEmpty()) { "Group chat title cannot be empty." }
            val myName = currentUser.displayName.take(50).ifBlank { "Student" }
            val participantUids = (listOf(activeUid) + friends.map { it.userId }).distinct().take(25)
            val participantNames = buildMap {
                put(activeUid, myName)
                friends.take(24).forEach { put(it.userId, it.displayName.take(50).ifBlank { "Classmate" }) }
            }
            val others = participantUids.filter { it != activeUid }

            val batch = db.batch()
            batch.set(
                convRef,
                mapOf(
                    "title" to cleanTitle,
                    "chatType" to "group",
                    "createdBy" to activeUid,
                    "participantUids" to participantUids,
                    "participantNames" to participantNames,
                    "lastMessageText" to "Created group study chat",
                    "lastMessageSenderId" to activeUid,
                    "lastMessageSenderName" to myName,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadByUids" to others,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            others.forEach { recipientUid ->
                val notifRef = db.collection("users").document(recipientUid)
                    .collection("notifications").document()
                batch.set(
                    notifRef,
                    mapOf(
                        "recipientUid" to recipientUid,
                        "senderUid" to activeUid,
                        "senderName" to myName,
                        "notifType" to "new_message",
                        "title" to cleanTitle,
                        "body" to "$myName added you to $cleanTitle.",
                        "targetId" to convRef.id,
                        "unread" to true,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(convRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun sendMessage(
        conversation: Conversation,
        sender: UserAccount,
        rawText: String,
        messageType: String = "text"
    ): Result<Unit> {
        val convRef = db.collection("conversations").document(conversation.id)
        val msgRef = convRef.collection("messages").document()
        val path = msgRef.path
        return try {
            val activeUid = requireUserId()
            val cleanText = rawText.trim().take(1000)
            require(cleanText.isNotEmpty()) { "Message cannot be empty." }
            val senderName = sender.displayName.take(50).ifBlank { "Student" }
            val participants = conversation.participantUids.ifEmpty { listOf(activeUid) }.take(25)
            val recipients = participants.filter { it != activeUid }

            val batch = db.batch()
            batch.set(
                msgRef,
                mapOf(
                    "conversationId" to conversation.id,
                    "senderId" to activeUid,
                    "senderName" to senderName,
                    "text" to cleanText,
                    "messageType" to messageType,
                    "participantUids" to participants,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                convRef,
                mapOf(
                    "lastMessageText" to cleanText.take(500),
                    "lastMessageSenderId" to activeUid,
                    "lastMessageSenderName" to senderName,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadByUids" to recipients,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            recipients.forEach { recipientUid ->
                val notifRef = db.collection("users").document(recipientUid)
                    .collection("notifications").document()
                val title = if (conversation.chatType == "private") {
                    "New message from $senderName"
                } else {
                    "${conversation.title} • $senderName"
                }
                batch.set(
                    notifRef,
                    mapOf(
                        "recipientUid" to recipientUid,
                        "senderUid" to activeUid,
                        "senderName" to senderName,
                        "notifType" to "new_message",
                        "title" to title.take(100),
                        "body" to cleanText.take(300),
                        "targetId" to conversation.id,
                        "unread" to true,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markConversationRead(conversation: Conversation, uid: String): Result<Unit> {
        if (!conversation.unreadByUids.contains(uid)) return Result.success(Unit)
        val path = "conversations/${conversation.id}"
        return try {
            val activeUid = requireUserId()
            check(activeUid == uid)
            val updatedUnread = conversation.unreadByUids.filter { it != activeUid }
            db.collection("conversations").document(conversation.id)
                .update(
                    mapOf(
                        "unreadByUids" to updatedUnread,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- Study Together Rooms ---

    suspend fun createStudyRoom(
        currentUser: UserAccount,
        title: String,
        subject: String,
        description: String,
        visibility: String,
        focusMinutes: Long
    ): Result<String> {
        val roomRef = db.collection("study_rooms").document()
        val convRef = db.collection("conversations").document()
        val path = roomRef.path
        return try {
            val activeUid = requireUserId()
            val cleanTitle = title.trim().take(80)
            val cleanSubject = subject.trim().take(50).ifBlank { "General" }
            val cleanDesc = description.trim().take(300)
            require(cleanTitle.isNotEmpty()) { "Room title cannot be empty." }
            val cleanVisibility = if (visibility == "invite") "invite" else "open"
            val clampedMinutes = focusMinutes.coerceIn(5L, 180L)
            val hostName = currentUser.displayName.take(50).ifBlank { "Host" }
            val roomCode = generateRoomCode()
            val codeRef = db.collection("room_codes").document(roomCode)

            val batch = db.batch()
            batch.set(
                convRef,
                mapOf(
                    "title" to cleanTitle,
                    "chatType" to "group",
                    "roomId" to roomRef.id,
                    "createdBy" to activeUid,
                    "participantUids" to listOf(activeUid),
                    "participantNames" to mapOf(activeUid to hostName),
                    "lastMessageText" to "Study room started ($clampedMinutes min focus)",
                    "lastMessageSenderId" to activeUid,
                    "lastMessageSenderName" to hostName,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadByUids" to emptyList<String>(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                roomRef,
                mapOf(
                    "title" to cleanTitle,
                    "subject" to cleanSubject,
                    "description" to cleanDesc,
                    "roomCode" to roomCode,
                    "visibility" to cleanVisibility,
                    "status" to "active",
                    "focusMinutes" to clampedMinutes,
                    "hostUid" to activeUid,
                    "hostName" to hostName,
                    "participantUids" to listOf(activeUid),
                    "participantNames" to mapOf(activeUid to hostName),
                    "conversationId" to convRef.id,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                codeRef,
                mapOf(
                    "roomId" to roomRef.id,
                    "roomCode" to roomCode,
                    "title" to cleanTitle,
                    "subject" to cleanSubject,
                    "hostUid" to activeUid,
                    "hostName" to hostName,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(roomRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun joinStudyRoomByCode(currentUser: UserAccount, rawCode: String): Result<String> {
        val cleanCode = rawCode.trim().uppercase()
        val path = "room_codes/$cleanCode"
        return try {
            requireUserId()
            require(cleanCode.matches(Regex("^[A-Z0-9\\-]{4,16}$"))) {
                "Enter a valid Room Code (e.g. RM-4821)."
            }
            val codeSnap = db.collection("room_codes").document(cleanCode).get().await()
            if (!codeSnap.exists()) {
                return Result.failure(IllegalArgumentException("No active study room found for $cleanCode."))
            }
            val roomId = codeSnap.getString("roomId")
                ?: return Result.failure(IllegalStateException("Room code entry is incomplete."))
            val roomSnap = db.collection("study_rooms").document(roomId).get().await()
            val room = roomSnap.toObject(StudyRoom::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalStateException("Study room no longer exists."))
            if (room.status == "ended") {
                return Result.failure(IllegalStateException("This study room has already ended."))
            }
            joinStudyRoom(currentUser, room).getOrThrow()
            Result.success(room.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun joinStudyRoom(currentUser: UserAccount, room: StudyRoom): Result<Unit> {
        val path = "study_rooms/${room.id}"
        return try {
            val activeUid = requireUserId()
            if (room.status == "ended") {
                return Result.failure(IllegalStateException("This study room has ended."))
            }
            if (room.participantUids.contains(activeUid)) {
                return Result.success(Unit)
            }
            require(room.participantUids.size < 25) { "This study room is full (25/25)." }
            val myName = currentUser.displayName.take(50).ifBlank { "Student" }
            val updatedUids = (room.participantUids + activeUid).distinct()
            val updatedNames = room.participantNames + (activeUid to myName)

            val batch = db.batch()
            batch.update(
                db.collection("study_rooms").document(room.id),
                mapOf(
                    "participantUids" to updatedUids,
                    "participantNames" to updatedNames,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (room.conversationId.isNotBlank()) {
                batch.update(
                    db.collection("conversations").document(room.conversationId),
                    mapOf(
                        "participantUids" to updatedUids,
                        "participantNames" to updatedNames,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun leaveStudyRoom(uid: String, room: StudyRoom): Result<Unit> {
        val path = "study_rooms/${room.id}"
        return try {
            val activeUid = requireUserId()
            check(activeUid == uid)
            if (room.hostUid == activeUid) {
                return endStudyRoom(room)
            }
            val remainingUids = room.participantUids.filter { it != activeUid }
            val remainingNames = room.participantNames - activeUid
            if (remainingUids.isEmpty()) {
                return endStudyRoom(room)
            }
            db.collection("study_rooms").document(room.id)
                .update(
                    mapOf(
                        "participantUids" to remainingUids,
                        "participantNames" to remainingNames,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun endStudyRoom(room: StudyRoom): Result<Unit> {
        val path = "study_rooms/${room.id}"
        return try {
            val activeUid = requireUserId()
            require(room.hostUid == activeUid) { "Only the host can end the study room." }
            db.collection("study_rooms").document(room.id)
                .update(
                    mapOf(
                        "status" to "ended",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun inviteFriendToRoom(
        currentUser: UserAccount,
        friendUid: String,
        room: StudyRoom
    ): Result<Unit> {
        val notifRef = db.collection("users").document(friendUid).collection("notifications").document()
        val path = notifRef.path
        return try {
            val activeUid = requireUserId()
            val myName = currentUser.displayName.take(50).ifBlank { "Classmate" }
            notifRef.set(
                mapOf(
                    "recipientUid" to friendUid,
                    "senderUid" to activeUid,
                    "senderName" to myName,
                    "notifType" to "study_invite",
                    "title" to "Study invite: ${room.title}".take(100),
                    "body" to "$myName invited you to ${room.subject} (Code: ${room.roomCode}).".take(300),
                    "targetId" to room.id,
                    "unread" to true,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // --- Notifications ---

    suspend fun markNotificationRead(uid: String, notificationId: String): Result<Unit> {
        val path = "users/$uid/notifications/$notificationId"
        return try {
            val activeUid = requireUserId()
            check(activeUid == uid)
            db.collection("users").document(uid)
                .collection("notifications").document(notificationId)
                .update(mapOf("unread" to false))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markAllNotificationsRead(uid: String, unreadIds: List<String>): Result<Unit> {
        if (unreadIds.isEmpty()) return Result.success(Unit)
        val path = "users/$uid/notifications"
        return try {
            val activeUid = requireUserId()
            check(activeUid == uid)
            val batch = db.batch()
            unreadIds.take(50).forEach { id ->
                batch.update(
                    db.collection("users").document(uid).collection("notifications").document(id),
                    mapOf("unread" to false)
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- Progress & Study Sessions ---

    suspend fun logStudySession(
        uid: String,
        subject: String,
        durationMinutes: Long,
        roomTitle: String,
        mode: String
    ): Result<Unit> {
        val sessRef = db.collection("users").document(uid).collection("study_sessions").document()
        val path = sessRef.path
        return try {
            val activeUid = requireUserId()
            check(activeUid == uid)
            val cleanSubject = subject.trim().take(60).ifBlank { "Focused Study" }
            val clampedMinutes = durationMinutes.coerceIn(1L, 360L)
            val cleanMode = if (mode == "group") "group" else "solo"
            val cleanRoomTitle = roomTitle.trim().take(80)

            val batch = db.batch()
            batch.set(
                sessRef,
                mapOf(
                    "userId" to activeUid,
                    "subject" to cleanSubject,
                    "durationMinutes" to clampedMinutes,
                    "roomTitle" to cleanRoomTitle,
                    "mode" to cleanMode,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("users").document(activeUid),
                mapOf(
                    "totalStudyMinutes" to FieldValue.increment(clampedMinutes),
                    "sessionsCompleted" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("public_profiles").document(activeUid),
                mapOf(
                    "totalStudyMinutes" to FieldValue.increment(clampedMinutes),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }
}

package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserAccount(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val studyCode: String = "",
    val major: String = "",
    val statusText: String = "",
    val online: Boolean = true,
    val dailyGoalMinutes: Long = 90L,
    val notificationsEnabled: Boolean = true,
    val totalStudyMinutes: Long = 0L,
    val streakDays: Long = 1L,
    val sessionsCompleted: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PublicProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val studyCode: String = "",
    val major: String = "",
    val statusText: String = "",
    val online: Boolean = false,
    val totalStudyMinutes: Long = 0L,
    val streakDays: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StudyCodeEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val major: String = "",
    val studyCode: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FriendRequest(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val fromName: String = "",
    val fromMajor: String = "",
    val fromStudyCode: String = "",
    val toUid: String = "",
    val toName: String = "",
    val toMajor: String = "",
    val toStudyCode: String = "",
    val participantUids: List<String> = emptyList(),
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val title: String = "",
    val chatType: String = "private",
    val roomId: String? = null,
    val createdBy: String = "",
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val lastMessageText: String = "",
    val lastMessageSenderId: String = "",
    val lastMessageSenderName: String = "",
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    val unreadByUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val messageType: String = "text",
    val participantUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StudyRoom(
    @DocumentId val id: String = "",
    val title: String = "",
    val subject: String = "",
    val description: String = "",
    val roomCode: String = "",
    val visibility: String = "open",
    val status: String = "active",
    val focusMinutes: Long = 25L,
    val hostUid: String = "",
    val hostName: String = "",
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val conversationId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RoomCodeEntry(
    @DocumentId val id: String = "",
    val roomId: String = "",
    val roomCode: String = "",
    val title: String = "",
    val subject: String = "",
    val hostUid: String = "",
    val hostName: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val recipientUid: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val notifType: String = "new_message",
    val title: String = "",
    val body: String = "",
    val targetId: String = "",
    val unread: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class StudySession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val subject: String = "",
    val durationMinutes: Long = 25L,
    val roomTitle: String = "",
    val mode: String = "solo",
    @ServerTimestamp val createdAt: Timestamp? = null
)

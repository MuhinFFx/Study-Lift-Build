const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_101";
const BOB_UID = "bob_uid_202";
const CAROL_UID = "carol_uid_303";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastTime(offsetMs = 2000) {
  return new Date(Date.now() - offsetMs);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: denied across all collections", async () => {
  const db = testEnv.unauthenticatedContext().firestore();
  await assertFails(db.collection("users").doc(ALICE_UID).get());
  await assertFails(db.collection("public_profiles").doc(ALICE_UID).get());
  await assertFails(db.collection("study_codes").doc("SL-ALICE").get());
  await assertFails(db.collection("friend_requests").where("participantUids", "array-contains", ALICE_UID).get());
  await assertFails(db.collection("conversations").where("participantUids", "array-contains", ALICE_UID).get());
  await assertFails(db.collection("study_rooms").where("visibility", "==", "open").get());
});

test("Users & Public Profiles: owner isolation, PII protection, and no scraping", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastTime();

  const aliceUser = {
    userId: ALICE_UID,
    email: "alice@campus.edu",
    displayName: "Alice Lin",
    studyCode: "SL-ALICE1",
    major: "Computer Science",
    statusText: "Ready to study",
    online: true,
    dailyGoalMinutes: 90,
    notificationsEnabled: true,
    totalStudyMinutes: 120,
    streakDays: 3,
    sessionsCompleted: 4,
    createdAt: now,
    updatedAt: now,
  };

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(aliceUser));
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      dailyGoalMinutes: 120,
      statusText: "Studying Algorithms",
      updatedAt: pastTime(500),
    })
  );

  // Bob cannot read or write Alice's private PII user doc
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ displayName: "Hacked" }));

  // Ghost field & @DocumentId 'id' rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: pastTime(200),
    })
  );
  await assertFails(
    bobDb.collection("users").doc(BOB_UID).set({
      ...aliceUser,
      id: BOB_UID,
      userId: BOB_UID,
      studyCode: "SL-BOB001",
    })
  );

  // Public profile: single-doc get allowed, list scraping denied, cross-user write denied
  const alicePublic = {
    userId: ALICE_UID,
    displayName: "Alice Lin",
    studyCode: "SL-ALICE1",
    major: "Computer Science",
    statusText: "Ready to study",
    online: true,
    totalStudyMinutes: 120,
    streakDays: 3,
    createdAt: now,
    updatedAt: now,
  };
  await assertSucceeds(aliceDb.collection("public_profiles").doc(ALICE_UID).set(alicePublic));
  await assertSucceeds(bobDb.collection("public_profiles").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("public_profiles").get());
  await assertFails(bobDb.collection("public_profiles").doc(ALICE_UID).update({ online: false }));
});

test("Study Codes & Friend Requests: lookup by exact code, pending -> accepted, cross-user denial", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const carolDb = testEnv.authenticatedContext(CAROL_UID).firestore();
  const now = pastTime();

  await assertSucceeds(
    bobDb.collection("study_codes").doc("SL-BOB001").set({
      userId: BOB_UID,
      displayName: "Bob Chen",
      major: "Biology",
      studyCode: "SL-BOB001",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Exact lookup works; list scraping fails
  await assertSucceeds(aliceDb.collection("study_codes").doc("SL-BOB001").get());
  await assertFails(aliceDb.collection("study_codes").get());

  // Alice sends friend request to Bob
  const reqId = `${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("friend_requests").doc(reqId).set({
      fromUid: ALICE_UID,
      fromName: "Alice Lin",
      fromMajor: "Computer Science",
      fromStudyCode: "SL-ALICE1",
      toUid: BOB_UID,
      toName: "Bob Chen",
      toMajor: "Biology",
      toStudyCode: "SL-BOB001",
      participantUids: [ALICE_UID, BOB_UID],
      status: "pending",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Aligned list query succeeds, unfiltered list fails
  await assertSucceeds(
    bobDb.collection("friend_requests").where("participantUids", "array-contains", BOB_UID).get()
  );
  await assertFails(carolDb.collection("friend_requests").get());
  await assertFails(carolDb.collection("friend_requests").doc(reqId).get());

  // Alice (sender) cannot self-accept her own outgoing request
  await assertFails(
    aliceDb.collection("friend_requests").doc(reqId).update({
      status: "accepted",
      updatedAt: pastTime(500),
    })
  );

  // Bob (recipient) accepts the request
  await assertSucceeds(
    bobDb.collection("friend_requests").doc(reqId).update({
      status: "accepted",
      updatedAt: pastTime(400),
    })
  );

  // Once accepted, status cannot be flipped back
  await assertFails(
    bobDb.collection("friend_requests").doc(reqId).update({
      status: "declined",
      updatedAt: pastTime(200),
    })
  );
});

test("Conversations & Messages: private chat, group study chat, participant isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const carolDb = testEnv.authenticatedContext(CAROL_UID).firestore();
  const now = pastTime();

  const dmId = `dm_${ALICE_UID}_${BOB_UID}`;
  await assertSucceeds(
    aliceDb.collection("conversations").doc(dmId).set({
      title: "Alice & Bob",
      chatType: "private",
      createdBy: ALICE_UID,
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "Alice Lin", [BOB_UID]: "Bob Chen" },
      lastMessageText: "Hey, want to study Calculus?",
      lastMessageSenderId: ALICE_UID,
      lastMessageSenderName: "Alice Lin",
      lastMessageAt: now,
      unreadByUids: [BOB_UID],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Carol cannot read or join a private DM
  await assertFails(carolDb.collection("conversations").doc(dmId).get());
  await assertFails(
    carolDb.collection("conversations").doc(dmId).update({
      participantUids: [ALICE_UID, BOB_UID, CAROL_UID],
      participantNames: { [ALICE_UID]: "Alice Lin", [BOB_UID]: "Bob Chen", [CAROL_UID]: "Carol" },
      updatedAt: pastTime(500),
    })
  );

  // Alice sends a message with denormalized participantUids
  await assertSucceeds(
    aliceDb.collection("conversations").doc(dmId).collection("messages").doc("msg_1").set({
      conversationId: dmId,
      senderId: ALICE_UID,
      senderName: "Alice Lin",
      text: "Hey, want to study Calculus?",
      messageType: "text",
      participantUids: [ALICE_UID, BOB_UID],
      createdAt: now,
    })
  );

  // Bob queries messages with aligned participantUids filter & marks conversation read
  await assertSucceeds(
    bobDb.collection("conversations").doc(dmId).collection("messages")
      .where("participantUids", "array-contains", BOB_UID)
      .get()
  );
  await assertSucceeds(
    bobDb.collection("conversations").doc(dmId).update({
      unreadByUids: [],
      updatedAt: pastTime(300),
    })
  );

  // Carol cannot inject a message into Alice & Bob's DM
  await assertFails(
    carolDb.collection("conversations").doc(dmId).collection("messages").doc("msg_bad").set({
      conversationId: dmId,
      senderId: CAROL_UID,
      senderName: "Carol",
      text: "Intruder",
      messageType: "text",
      participantUids: [ALICE_UID, BOB_UID, CAROL_UID],
      createdAt: now,
    })
  );

  // Group conversation allows Carol to join
  const groupId = "group_calc_1";
  await assertSucceeds(
    aliceDb.collection("conversations").doc(groupId).set({
      title: "Calculus Study Group",
      chatType: "group",
      roomId: "room_calc_1",
      createdBy: ALICE_UID,
      participantUids: [ALICE_UID],
      participantNames: { [ALICE_UID]: "Alice Lin" },
      lastMessageText: "Room created",
      lastMessageSenderId: ALICE_UID,
      lastMessageSenderName: "Alice Lin",
      lastMessageAt: now,
      unreadByUids: [],
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    carolDb.collection("conversations").doc(groupId).update({
      participantUids: [ALICE_UID, CAROL_UID],
      participantNames: { [ALICE_UID]: "Alice Lin", [CAROL_UID]: "Carol" },
      updatedAt: pastTime(200),
    })
  );
});

test("Study Rooms & Room Codes: create, list open/joined, join, terminal ended lock", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = pastTime();

  await assertSucceeds(
    aliceDb.collection("study_rooms").doc("room_1").set({
      title: "Organic Chem Review",
      subject: "Chemistry",
      description: "25m focus sprints",
      roomCode: "RM-CHEM1",
      visibility: "open",
      status: "active",
      focusMinutes: 25,
      hostUid: ALICE_UID,
      hostName: "Alice Lin",
      participantUids: [ALICE_UID],
      participantNames: { [ALICE_UID]: "Alice Lin" },
      conversationId: "group_room_1",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("room_codes").doc("RM-CHEM1").set({
      roomId: "room_1",
      roomCode: "RM-CHEM1",
      title: "Organic Chem Review",
      subject: "Chemistry",
      hostUid: ALICE_UID,
      hostName: "Alice Lin",
      createdAt: now,
    })
  );

  // Open rooms query & joined rooms query succeed; unfiltered query fails
  await assertSucceeds(bobDb.collection("study_rooms").where("visibility", "==", "open").get());
  await assertSucceeds(aliceDb.collection("study_rooms").where("participantUids", "array-contains", ALICE_UID).get());
  await assertFails(bobDb.collection("study_rooms").get());

  // Bob joins room_1
  await assertSucceeds(
    bobDb.collection("study_rooms").doc("room_1").update({
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "Alice Lin", [BOB_UID]: "Bob Chen" },
      updatedAt: pastTime(500),
    })
  );

  // Non-host Bob cannot change room status
  await assertFails(
    bobDb.collection("study_rooms").doc("room_1").update({
      status: "ended",
      updatedAt: pastTime(400),
    })
  );

  // Host Alice ends room -> terminal state locked
  await assertSucceeds(
    aliceDb.collection("study_rooms").doc("room_1").update({
      status: "ended",
      updatedAt: pastTime(300),
    })
  );
  await assertFails(
    aliceDb.collection("study_rooms").doc("room_1").update({
      status: "active",
      updatedAt: pastTime(100),
    })
  );
});

test("Notifications & Study Sessions: sender-stamped notif create, owner-only read/mark-read", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const carolDb = testEnv.authenticatedContext(CAROL_UID).firestore();
  const now = pastTime();

  // Alice sends a new_message notification to Bob
  await assertSucceeds(
    aliceDb.collection("users").doc(BOB_UID).collection("notifications").doc("notif_1").set({
      recipientUid: BOB_UID,
      senderUid: ALICE_UID,
      senderName: "Alice Lin",
      notifType: "new_message",
      title: "New message from Alice Lin",
      body: "Hey, want to study Calculus?",
      targetId: "dm_1",
      unread: true,
      createdAt: now,
    })
  );

  // Carol cannot forge a notification pretending to be Alice, and cannot read Bob's inbox
  await assertFails(
    carolDb.collection("users").doc(BOB_UID).collection("notifications").doc("notif_spoof").set({
      recipientUid: BOB_UID,
      senderUid: ALICE_UID,
      senderName: "Alice Lin",
      notifType: "new_message",
      title: "Spoof",
      body: "Spoofed",
      targetId: "dm_1",
      unread: true,
      createdAt: now,
    })
  );
  await assertFails(aliceDb.collection("users").doc(BOB_UID).collection("notifications").get());

  // Bob lists and marks his notification as read
  await assertSucceeds(bobDb.collection("users").doc(BOB_UID).collection("notifications").get());
  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).collection("notifications").doc("notif_1").update({
      unread: false,
    })
  );

  // Study sessions: strictly owner-only
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("study_sessions").doc("sess_1").set({
      userId: ALICE_UID,
      subject: "Algorithms",
      durationMinutes: 45,
      roomTitle: "Solo Focus",
      mode: "solo",
      createdAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("study_sessions").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("study_sessions").get());
});
